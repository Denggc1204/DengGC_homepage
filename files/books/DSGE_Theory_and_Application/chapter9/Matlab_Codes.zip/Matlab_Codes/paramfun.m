function param = paramfun
% 设定参数值
bet      =      0.990;
vphi     =      3.000;
eps      =      10.00;
tht      =      0.750;
rhor     =      0.800;
phiy     =      0.125;
phipi    =      1.500;
rhoa     =      0.880;
siga     =      0.010;
param = [bet, vphi, eps, tht, rhor, phiy, phipi, rhoa, siga];