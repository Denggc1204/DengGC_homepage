%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 第9章：福利分析。四种情形：
% （1）通胀目标制
% （2）标准泰勒规则
% （3）带利率平滑的泰勒规则
% （4）对产出作出反应的泰勒规则
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 作者: Deng, Guichuan                       
% 邮箱: denggch@mail.sysu.edu.cn            
% 最新更新时间: 2026/10/12                  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 建立子文件夹
mkdir('./result');

%% 一阶近似
%%%%%%%%%%%%%%%%%%
% 通胀目标制
%%%%%%%%%%%%%%%%%%
clear; 
close all;
clc; 

% 求解和模拟
dynare welfare.mod -Dkk=1; % mp_pi

% 保存结果
ob1 = oo_;
save('./result./ob1.mat', 'ob1');
save('./result./M_.mat', 'M_');

%%%%%%%%%%%%%%%%%%%%
% 标准泰勒规则
%%%%%%%%%%%%%%%%%%%%
clear; 
close all;
clc; 

% 求解和模拟
dynare welfare.mod -Dkk=2; % mp_ygap,pi

% 保存结果
ogap1 = oo_;
save('./result./ogap1.mat', 'ogap1');

%%%%%%%%%%%%%%%%%%%%%%%%%
% 带利率平滑泰勒规则
%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all;
clc; 

% 求解和模拟
dynare welfare.mod -Dkk=3; % mp_r,ygap,pi

% 保存结果
os1 = oo_;
save('./result./os1.mat', 'os1');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 对产出作出反应的泰勒规则
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all;
clc; 

% 求解和模拟
dynare welfare.mod -Dkk=4; % mp_y,pi

% 保存结果
oo1 = oo_;
save('./result./oo1.mat', 'oo1');


%% 二阶近似
%%%%%%%%%%%%%%%%%%
% 通胀目标制
%%%%%%%%%%%%%%%%%%
clear; 
close all;
clc; 

% 求解和模拟
dynare welfare.mod -Dkk=1 -DSEC=1; % mp_pi

% 保存结果
ob2 = oo_;
save('./result./ob2.mat', 'ob2');

%%%%%%%%%%%%%%%%%%%%
% 标准泰勒规则
%%%%%%%%%%%%%%%%%%%%
clear; 
close all;
clc; 

% 求解和模拟
dynare welfare.mod -Dkk=2 -DSEC=1; % mp_ygap,pi

% 保存结果
ogap2 = oo_;
save('./result./ogap2.mat', 'ogap2');

%%%%%%%%%%%%%%%%%%%%%%%%%
% 带利率平滑泰勒规则
%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all;
clc; 

% 求解和模拟
dynare welfare.mod -Dkk=3 -DSEC=1; % mp_r,ygap,pi

% 保存结果
os2 = oo_;
save('./result./os2.mat', 'os2');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 对产出作出反应的泰勒规则
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all;
clc; 

% 求解和模拟
dynare welfare.mod -Dkk=4 -DSEC=1; % mp_y,pi

% 保存结果
oo2 = oo_;
save('./result./oo2.mat', 'oo2');


%% 计算社会福利损失
clear; 
close all;
clc; 

% 加载数据
load('./result./ob1.mat');
load('./result./ogap1.mat');
load('./result./os1.mat');
load('./result./oo1.mat');
load('./result./ob2.mat');
load('./result./ogap2.mat');
load('./result./os2.mat');
load('./result./oo2.mat');
load('./result./M_.mat');

% 提取变量和参数位置信息
ypos     = strmatch('y',       M_.endo_names ,'exact');
ygappos  = strmatch('ygap',    M_.endo_names ,'exact');
pipos    = strmatch('pi',      M_.endo_names ,'exact');
npos     = strmatch('n',       M_.endo_names ,'exact');
rpos     = strmatch('r',       M_.endo_names ,'exact');
welpos   = strmatch('wel',     M_.endo_names ,'exact');
betpos  = strmatch('bet',    M_.param_names ,'exact');
varpos   = strmatch('vphi',  M_.param_names ,'exact');
thtpos = strmatch('tht',   M_.param_names ,'exact');
epspos   = strmatch('eps', M_.param_names ,'exact');

% 提取参数值
bet    = M_.params(betpos);
vphi   = M_.params(varpos);
tht    = M_.params(thtpos);
eps    = M_.params(epspos);
kappa  = (1-tht)*(1-bet*tht)/tht;

% 福利（或效用）无条件均值和条件均值
wel = [ob1.mean(welpos),   ob1.dr.ys(welpos),       ob2.mean(welpos),   ob2.dr.ys(welpos)+0.5*ob2.dr.ghs2(ob2.dr.inv_order_var(welpos));
       ogap1.mean(welpos), ogap1.dr.ys(welpos),     ogap2.mean(welpos), ogap2.dr.ys(welpos)+0.5*ogap2.dr.ghs2(ogap2.dr.inv_order_var(welpos));
       os1.mean(welpos),   os1.dr.ys(welpos),       os2.mean(welpos),   os2.dr.ys(welpos)+0.5*os2.dr.ghs2(os2.dr.inv_order_var(welpos));
       oo1.mean(welpos),   oo1.dr.ys(welpos),       oo2.mean(welpos),   oo2.dr.ys(welpos)+0.5*oo2.dr.ghs2(oo2.dr.inv_order_var(welpos))];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 文件中 paramfun.m 中，设定 tht = 0.25，运行 run.m 文件，表 9.5：Vol
% 文件中 paramfun.m 中，设定 tht = 0.50，运行 run.m 文件，表 9.6：Vol
% 文件中 paramfun.m 中，设定 tht = 0.75，运行 run.m 文件，表 9.7：Vol
% 表9.8：三次运行结果得到的 Vol 汇总得到表9.8
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
WL = round([%
    % standard method
    eps/(kappa)*ob1.var(pipos,pipos)+(1+vphi)*ob1.var(ygappos,ygappos), eps/kappa*ogap1.var(pipos,pipos)+(1+vphi)*ogap1.var(ygappos,ygappos), eps/kappa*os1.var(pipos,pipos)+(1+vphi)*os1.var(ygappos,ygappos), eps/kappa*oo1.var(pipos,pipos)+(1+vphi)*oo1.var(ygappos,ygappos); % 1st
    eps/(kappa)*ob2.var(pipos,pipos)+(1+vphi)*ob2.var(ygappos,ygappos), eps/kappa*ogap2.var(pipos,pipos)+(1+vphi)*ogap2.var(ygappos,ygappos), eps/kappa*os2.var(pipos,pipos)+(1+vphi)*os2.var(ygappos,ygappos), eps/kappa*oo2.var(pipos,pipos)+(1+vphi)*oo2.var(ygappos,ygappos); % 2nd
    % linear approx
    (1+vphi)^2/2*ob1.var(npos,npos),                                        (1+vphi)^2/2*ogap1.var(npos,npos),                                         (1+vphi)^2/2*os1.var(npos,npos),                                      (1+vphi)^2/2*oo1.var(npos,npos);    % 1st
    (1+vphi)^2/2*ob2.var(npos,npos),                                        (1+vphi)^2/2*ogap2.var(npos,npos),                                         (1+vphi)^2/2*os2.var(npos,npos),                                      (1+vphi)^2/2*oo2.var(npos,npos);    % 2nd
    % setting 1
    ob1.var(pipos,pipos)+0.5*ob1.var(ygappos,ygappos),                        ogap1.var(pipos,pipos)+0.5*ogap1.var(ygappos,ygappos),                       os1.var(pipos,pipos)+0.5*os1.var(ygappos,ygappos),                      oo1.var(pipos,pipos)+0.5*oo1.var(ygappos,ygappos);  % 1st
    ob1.var(pipos,pipos)+1.0*ob1.var(ygappos,ygappos),                        ogap1.var(pipos,pipos)+1.0*ogap1.var(ygappos,ygappos),                       os1.var(pipos,pipos)+1.0*os1.var(ygappos,ygappos),                      oo1.var(pipos,pipos)+1.0*oo1.var(ygappos,ygappos);  % 1st
    ob1.var(pipos,pipos)+1.5*ob1.var(ygappos,ygappos),                        ogap1.var(pipos,pipos)+1.5*ogap1.var(ygappos,ygappos),                       os1.var(pipos,pipos)+1.5*os1.var(ygappos,ygappos),                      oo1.var(pipos,pipos)+1.5*oo1.var(ygappos,ygappos);  % 1st
    ob2.var(pipos,pipos)+0.5*ob2.var(ygappos,ygappos),                        ogap2.var(pipos,pipos)+0.5*ogap2.var(ygappos,ygappos),                       os2.var(pipos,pipos)+0.5*os2.var(ygappos,ygappos),                      oo2.var(pipos,pipos)+0.5*oo2.var(ygappos,ygappos);  % 2nd
    ob2.var(pipos,pipos)+1.0*ob2.var(ygappos,ygappos),                        ogap2.var(pipos,pipos)+1.0*ogap2.var(ygappos,ygappos),                       os2.var(pipos,pipos)+1.0*os2.var(ygappos,ygappos),                      oo2.var(pipos,pipos)+1.0*oo2.var(ygappos,ygappos);  % 2nd
    ob2.var(pipos,pipos)+1.5*ob2.var(ygappos,ygappos),                        ogap2.var(pipos,pipos)+1.5*ogap2.var(ygappos,ygappos),                       os2.var(pipos,pipos)+1.5*os2.var(ygappos,ygappos),                      oo2.var(pipos,pipos)+1.5*oo2.var(ygappos,ygappos);  % 2nd
    % setting 2
    ob1.var(pipos,pipos)+0.5*ob1.var(ypos,ypos),                              ogap1.var(pipos,pipos)+0.5*ogap1.var(ypos,ypos),                             os1.var(pipos,pipos)+0.5*os1.var(ypos,ypos),                            oo1.var(pipos,pipos)+0.5*oo1.var(ypos,ypos);  % 1st
    ob1.var(pipos,pipos)+1.0*ob1.var(ypos,ypos),                              ogap1.var(pipos,pipos)+1.0*ogap1.var(ypos,ypos),                             os1.var(pipos,pipos)+1.0*os1.var(ypos,ypos),                            oo1.var(pipos,pipos)+1.0*oo1.var(ypos,ypos);  % 1st
    ob1.var(pipos,pipos)+1.5*ob1.var(ypos,ypos),                              ogap1.var(pipos,pipos)+1.5*ogap1.var(ypos,ypos),                             os1.var(pipos,pipos)+1.5*os1.var(ypos,ypos),                            oo1.var(pipos,pipos)+1.5*oo1.var(ypos,ypos);  % 1st
    ob2.var(pipos,pipos)+0.5*ob2.var(ypos,ypos),                              ogap2.var(pipos,pipos)+0.5*ogap2.var(ypos,ypos),                             os2.var(pipos,pipos)+0.5*os2.var(ypos,ypos),                            oo2.var(pipos,pipos)+0.5*oo2.var(ypos,ypos);  % 2nd
    ob2.var(pipos,pipos)+1.0*ob2.var(ypos,ypos),                              ogap2.var(pipos,pipos)+1.0*ogap2.var(ypos,ypos),                             os2.var(pipos,pipos)+1.0*os2.var(ypos,ypos),                            oo2.var(pipos,pipos)+1.0*oo2.var(ypos,ypos);  % 2nd
    ob2.var(pipos,pipos)+1.5*ob2.var(ypos,ypos),                              ogap2.var(pipos,pipos)+1.5*ogap2.var(ypos,ypos),                             os2.var(pipos,pipos)+1.5*os2.var(ypos,ypos),                            oo2.var(pipos,pipos)+1.5*oo2.var(ypos,ypos);  % 2nd
    % consumption equilibrium: unconditional v.s conditional
    0,                                                                        (1-exp((1-bet)*(wel(2,1) - wel(1,1)))),                                 (1-exp((1-bet)*(wel(3,1) - wel(1,1)))),                            (1-exp((1-bet)*(wel(4,1) - wel(1,1))));  % 1st, unconditional
    0,                                                                        (1-exp((1-bet)*(wel(2,2) - wel(1,2)))),                                 (1-exp((1-bet)*(wel(3,2) - wel(1,2)))),                            (1-exp((1-bet)*(wel(4,2) - wel(1,2))));  % 1st, conditional
    0,                                                                        (1-exp((1-bet)*(wel(2,3) - wel(1,3)))),                                 (1-exp((1-bet)*(wel(3,3) - wel(1,3)))),                            (1-exp((1-bet)*(wel(4,3) - wel(1,3))));  % 2nd, unconditional
    0,                                                                        (1-exp((1-bet)*(wel(2,4) - wel(1,4)))),                                 (1-exp((1-bet)*(wel(3,4) - wel(1,4)))),                            (1-exp((1-bet)*(wel(4,4) - wel(1,4))))   % 2nd, conditional
    ]*10000, 3);

Vol = round(sqrt([%
    ob1.var(ygappos, ygappos),   ob1.var(pipos, pipos),   ob1.var(ypos, ypos),   ob1.var(npos, npos);
    ogap1.var(ygappos, ygappos), ogap1.var(pipos, pipos), ogap1.var(ypos, ypos), ogap1.var(npos, npos);
    os1.var(ygappos, ygappos),   os1.var(pipos, pipos),   os1.var(ypos, ypos),   os1.var(npos, npos);
    oo1.var(ygappos, ygappos),   oo1.var(pipos, pipos),   oo1.var(ypos, ypos),   oo1.var(npos, npos);
    ob2.var(ygappos, ygappos),   ob2.var(pipos, pipos),   ob2.var(ypos, ypos),   ob2.var(npos, npos);
    ogap2.var(ygappos, ygappos), ogap2.var(pipos, pipos), ogap2.var(ypos, ypos), ogap2.var(npos, npos);
    os2.var(ygappos, ygappos),   os2.var(pipos, pipos),   os2.var(ypos, ypos),   os2.var(npos, npos);
    oo2.var(ygappos, ygappos),   oo2.var(pipos, pipos),   oo2.var(ypos, ypos),   oo2.var(npos, npos)
    ])*100, 3);

xlswrite('./result./Welfare_Loss.xlsx', WL, 3);
xlswrite('./result./Volatility.xlsx', Vol, 3);
