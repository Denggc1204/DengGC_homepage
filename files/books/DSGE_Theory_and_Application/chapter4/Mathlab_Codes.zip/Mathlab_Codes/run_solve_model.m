%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% �����ʱ����RBCģ����⣬�������Σ�  %
% ��1��rho = 0.88                      %
% ��2��rho = 0                         %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ����: Deng, Guichuan                 %
% ����: denggch@mail.sysu.edu.cn       %
% ���¸���ʱ��: 2026/10/12             %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all;
clc; 

% �ڵ�ǰ�ļ��д������ļ���results
mkdir('./results')

%%%%%%%%%%%%%%%%%%%%%%%%%%
% ���ģ��: rho = 0.88
%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all;
clc; 

% ������ rho ��ֵ
rho = 0.88; 

% ����ģ��
dynare capital;

% ������
co = oo_; cm = M_;
save('./results./co.mat', 'co');
save('./results./cm.mat', 'cm');

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ���ģ��: rho = 0 
%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all;
clc; 

% ������ rho ��ֵ
rho = 0.00; 

% ����ģ��
dynare capital;

% ������
co0 = oo_; cm0 = M_;
save('./results./co0.mat', 'co0');

%%
%%%%%%%%%%%%%%%%%%%%%
% ģ�ͷ���          %
%%%%%%%%%%%%%%%%%%%%%
clear; 
close all; 
clc;

% ���ع��ƽ��
load('./results./co.mat');
% ���µ�ַ�Ǳ����׼ģ��������ĵ�ַ������߸����Լ�ʵ������޸ĵ�ַ
load('C:\Users\DanielDeng_Pro\OneDrive\�ĵ�\Papers\025_DSGE_Model_Theory_and_Bayesian_Estimation\Dynamic_Stochastic_General_Equilibrium_Model\code\chapter3\results_sec./lo.mat');
load('./results./cm.mat');

% ����������λ��
ypos = strmatch('y',    cm.endo_names,  'exact');
cpos = strmatch('c',    cm.endo_names,  'exact');
npos = strmatch('n',    cm.endo_names,  'exact');
kpos = strmatch('k',    cm.endo_names,  'exact');
ipos = strmatch('i',    cm.endo_names,  'exact');
wpos = strmatch('w',    cm.endo_names,  'exact');
rpos = strmatch('r',    cm.endo_names,  'exact');
rkpos= strmatch('rk',   cm.endo_names,  'exact');
apos = strmatch('a',    cm.endo_names,  'exact');

%%%%%%%%%%%%%%%%%%%%%%%%
% ת�Ʒ��̺����߷���ϵ��
%%%%%%%%%%%%%%%%%%%%%%%%
PF = round([co.dr.ys(ypos), co.dr.ghx(co.dr.inv_order_var(ypos),:), co.dr.ghu(co.dr.inv_order_var(ypos));
    co.dr.ys(cpos), co.dr.ghx(co.dr.inv_order_var(cpos),:), co.dr.ghu(co.dr.inv_order_var(cpos));
    co.dr.ys(npos), co.dr.ghx(co.dr.inv_order_var(npos),:), co.dr.ghu(co.dr.inv_order_var(npos));
    co.dr.ys(kpos), co.dr.ghx(co.dr.inv_order_var(kpos),:), co.dr.ghu(co.dr.inv_order_var(kpos));
    co.dr.ys(ipos), co.dr.ghx(co.dr.inv_order_var(ipos),:), co.dr.ghu(co.dr.inv_order_var(ipos));
    co.dr.ys(wpos), co.dr.ghx(co.dr.inv_order_var(wpos),:), co.dr.ghu(co.dr.inv_order_var(wpos));
    co.dr.ys(rpos), co.dr.ghx(co.dr.inv_order_var(rpos),:), co.dr.ghu(co.dr.inv_order_var(rpos));
    co.dr.ys(rkpos), co.dr.ghx(co.dr.inv_order_var(rkpos),:), co.dr.ghu(co.dr.inv_order_var(rkpos));
    co.dr.ys(apos), co.dr.ghx(co.dr.inv_order_var(apos),:), co.dr.ghu(co.dr.inv_order_var(apos))], 3);

%%%%%%%%%%%%%%%%%%%%%%%%%
% ͼ4.2�� ���巴Ӧ����
%%%%%%%%%%%%%%%%%%%%%%%%%
T = 60; x = 1:T; fsize = 12; up = 0.1; down = 0.5;
h0 = figure;
set(h0, 'unit', 'centimeters', 'position', [2 2 14 12]);

subplot(3, 3, 1)
plot(x, co.irfs.y_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot(x, lo.irfs.y_etaa(x)*100, 'Color', [0.4,0.4,0.4], 'Linestyle', '-.', 'LineWidth', 1);
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$y_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(3, 3, 2)
plot(x, co.irfs.c_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot(x, lo.irfs.c_etaa(x)*100, 'Color', [0.4,0.4,0.4], 'Linestyle', '-.', 'LineWidth', 1);
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$c_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(3, 3, 3)
plot(x, co.irfs.n_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot(x, lo.irfs.n_etaa(x)*100, 'Color', [0.4,0.4,0.4], 'Linestyle', '-.', 'LineWidth', 1);
plot([0, T], [0, 0], 'Color', [0.2,0.2,0.2], 'Linestyle', '--', 'LineWidth', 1)
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$n_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(3, 3, 4)
plot(x, co.irfs.i_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot([0, T], [0, 0], 'Color', [0.2,0.2,0.2], 'Linestyle', '--', 'LineWidth', 1)
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$i_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(3, 3, 5)
plot(x, co.irfs.k_etaa(x)*100, 'k-', 'LineWidth', 1);
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$k_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(3, 3, 6)
plot(x, co.irfs.w_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot(x, lo.irfs.w_etaa(x)*100, 'Color', [0.4,0.4,0.4], 'Linestyle', '-.', 'LineWidth', 1);
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$\hat{w}_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(3, 3, 7)
plot(x, co.irfs.r_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot(x, lo.irfs.r_etaa(x)*100, 'Color', [0.4,0.4,0.4], 'Linestyle', '-.', 'LineWidth', 1);
hold off;
hold on;
plot([0, T], [0, 0], 'Color', [0.2,0.2,0.2], 'Linestyle', '--', 'LineWidth', 1)
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$\hat{r}_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(3, 3, 8)
plot(x, co.irfs.rk_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot([0, T], [0, 0], 'Color', [0.2,0.2,0.2], 'Linestyle', '--', 'LineWidth', 1)
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$\hat{r}_t^k$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(3, 3, 9)
plot(x, co.irfs.a_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot(x, lo.irfs.a_etaa(x)*100, 'Color', [0.4,0.4,0.4], 'Linestyle', '-.', 'LineWidth', 1);
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$a_t$', 'interpreter', 'latex', 'FontSize', fsize);

legend('�����ʱ�', '��׼RBC', 'position', [0.32, 0.01, 0.40, 0.05], ...
    'orientation', 'horizontal', 'Fontsize', fsize);
legend('boxoff')


%%%%%%%%%%%%%%%%%%
% ��������ֵ
%%%%%%%%%%%%%%%%%%
Mean = round([co.mean(ypos) co.mean(cpos) co.mean(ipos) co.mean(npos);
    co.mean(kpos) co.mean(wpos) co.mean(rpos) co.mean(rkpos)], 3);

%%%%%%%%%%%%%%%%%%
% ��4.7����׼��
%%%%%%%%%%%%%%%%%%
Vol = round(sqrt([co.var(ypos, ypos) co.var(cpos, cpos) co.var(ipos, ipos)  co.var(npos, npos);
    co.var(kpos, kpos) co.var(wpos, wpos) co.var(rpos, rpos) co.var(rkpos, rkpos)])*100, 3);

%%%%%%%%%%%%%%%%%%%%%%%%%%
% ��4.8����������ϵ��
%%%%%%%%%%%%%%%%%%%%%%%%%%
Cor = round([1 co.var(ypos, cpos)/sqrt(co.var(ypos, ypos)*co.var(cpos, cpos)) co.var(ypos, ipos)/sqrt(co.var(ypos, ypos)*co.var(ipos, ipos)) co.var(ypos, npos)/sqrt(co.var(ypos, ypos)*co.var(npos, npos));
    co.var(ypos, kpos)/sqrt(co.var(ypos, ypos)*co.var(kpos, kpos)) co.var(ypos, wpos)/sqrt(co.var(ypos, ypos)*co.var(wpos, wpos)) co.var(ypos, rpos)/sqrt(co.var(ypos, ypos)*co.var(rpos, rpos))  co.var(ypos, rkpos)/sqrt(co.var(ypos, ypos)*co.var(rkpos, rkpos))], 3);

%%%%%%%%%%%%%%%%%%%%%%%
% ��4.9��һ�������ϵ��
%%%%%%%%%%%%%%%%%%%%%%%
Autocor = round([co.autocorr{1, 1}(ypos, ypos) co.autocorr{1, 1}(cpos, cpos) co.autocorr{1, 1}(ipos, ipos) co.autocorr{1, 1}(npos, npos);
    co.autocorr{1, 1}(kpos, kpos) co.autocorr{1, 1}(wpos, wpos) co.autocorr{1, 1}(rpos, rpos)  co.autocorr{1, 1}(rkpos, rkpos)], 3);

save('./results./Mean.mat', 'Mean');
save('./results./Vol.mat', 'Vol');
save('./results./Cor.mat', 'Cor');
save('./results./Autocor.mat', 'Autocor');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ͼ4.3�����巴Ӧ������rho=0
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; close all; clc;
load('./results./co0.mat');

T = 5; x = 1:T; fsize = 12; up = 0.1; down = 0.5;
h0 = figure;
set(h0, 'unit', 'centimeters', 'position', [2 2 14 12]);

subplot(3, 3, 1)
plot(x, co0.irfs.y_etaa(x)*100, 'k-', 'LineWidth', 1);
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$y_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(3, 3, 2)
plot(x, co0.irfs.c_etaa(x)*100, 'k-', 'LineWidth', 1);
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$c_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(3, 3, 3)
plot(x, co0.irfs.n_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot([0, T], [0, 0], 'Color', [0.2,0.2,0.2], 'Linestyle', '--', 'LineWidth', 1)
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$n_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(3, 3, 4)
plot(x, co0.irfs.i_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot([0, T], [0, 0], 'Color', [0.2,0.2,0.2], 'Linestyle', '--', 'LineWidth', 1)
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$i_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(3, 3, 5)
plot(x, co0.irfs.k_etaa(x)*100, 'k-', 'LineWidth', 1);
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$k_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(3, 3, 6)
plot(x, co0.irfs.w_etaa(x)*100, 'k-', 'LineWidth', 1);
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$\hat{w}_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(3, 3, 7)
plot(x, co0.irfs.r_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot([0, T], [0, 0], 'Color', [0.2,0.2,0.2], 'Linestyle', '--', 'LineWidth', 1)
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$\hat{r}_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(3, 3, 8)
plot(x, co0.irfs.rk_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot([0, T], [0, 0], 'Color', [0.2,0.2,0.2], 'Linestyle', '--', 'LineWidth', 1)
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$\hat{r}_t^k$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(3, 3, 9)
plot(x, co0.irfs.a_etaa(x)*100, 'k-', 'LineWidth', 1);
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$a_t$', 'interpreter', 'latex', 'FontSize', fsize);





