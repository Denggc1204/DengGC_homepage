%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 使用函数comp_thre计算临界值rhoast， 
% 当rhoa > rhoast时，资本脉冲反应呈现 
% “钟”形形态                        
% 运行该代码需要 comp_thre.m 文件
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 作者: Deng, Guichuan                
% 邮箱: denggch@mail.sysu.edu.cn      
% 最新更新时间: 2026/10/12            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all;
clc; 

% 输入参数值
bet=0.99; eps=10.0; alp=0.40; del=0.025;
mu=(eps-1)/eps; rss=1/bet; rkss=rss+del; 
Thet=alp*mu/(rkss-1); Psi=(1-alp)*bet*mu + Thet;
param = [bet, eps, alp, del];

rhoast1 = 1 - Thet/Psi;
rhoast2 = (1- Thet/Psi + sqrt((1-Thet/Psi)*(1+3*Thet/Psi)))/2;

% 求解冲击持续系数临界值
x0 = 0.6;
options = optimoptions('fsolve', 'Display', 'iter');
[rhoast3, fval]= fsolve(@(x) comp_thre(x, param, 1), x0, options); 
[rhoast4, fval]= fsolve(@(x) comp_thre(x, param, 2), x0, options); 
[rhoast5, fval]= fsolve(@(x) comp_thre(x, param, 3), x0, options); 
[rhoast6, fval]= fsolve(@(x) comp_thre(x, param, 4), x0, options); 
[rhoast7, fval]= fsolve(@(x) comp_thre(x, param, 5), x0, options); 
x0 = 0.1;
[rhoast8, fval]= fsolve(@(x) comp_thre(x, param, 6), x0, options); 
[rhoast9, fval]= fsolve(@(x) comp_thre(x, param, 7), x0, options); 
[rhoast10, fval]= fsolve(@(x) comp_thre(x, param, 8), x0, options); 
[rhoast11, fval]= fsolve(@(x) comp_thre(x, param, 9), x0, options); 
[rhoast12, fval]= fsolve(@(x) comp_thre(x, param, 10), x0, options); 

rhoast = round([rhoast1, rhoast2, rhoast3, rhoast4, rhoast5, rhoast6, ...
    rhoast7, rhoast8, rhoast9, rhoast10, rhoast11, rhoast12], 3);

%%%%%%%%%%%%%%%%%%%%%%%%%
% 图4.1：临界值变动图
%%%%%%%%%%%%%%%%%%%%%%%%%
fsize = 10; h0 = figure;
set(h0, 'Units','centimeters','Position', [2 2 14 8]);
plot(1:length(rhoast), rhoast, 'Color', [0,0,0], 'LineStyle', '-', 'LineWidth', 1.0, 'Marker', '^');
xlim([1, length(rhoast)]);
ylabel('$\rho^\ast$', 'interpreter', 'latex', 'Fontsize', 12)




