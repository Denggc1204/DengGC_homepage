%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 第5章：一阶近似求解价格黏性模型。两种情形：%
% （1）gap=0 & phipi=1.5                     %
% （2）gap=0 & phipi=20                      %
% （3）gap=0.73 & phipi=1.5                  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 作者: Deng, Guichuan                       %
% 邮箱: denggch@mail.sysu.edu.cn             %
% 最新更新时间: 2026/10/12                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all;
clc; 

% 在当前文件夹下新建子文件夹 results
mkdir('./results')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 求解基准模型: phipi=1.5 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all;
clc; 

% 设定参数值
gap=0.73; 
phipi = 1.5; 

% 求解和模拟
dynare pricesticky;

% 保存结果
bo = oo_; bm = M_;
save('./results./bo.mat', 'bo');
save('./results./bm.mat', 'bm');

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 严货币政策：phipi=20
%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all;
clc; 

% 设定参数值
gap=0.73; 
phipi = 20; 

% 求解和模拟
dynare pricesticky;

% 保存结果
spo = oo_; 
save('./results./spo.mat', 'spo');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 价格指数化调整：phipi=1.5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all;
clc; 

% 设定参数值
gap=0.73; 
phipi = 1.5; 

% 求解和模拟: 对于宏观变量 index，其赋值方式为 -D+宏变量，比如：-Dindex
dynare pricesticky -Dindex=1;

% 保存结果
bio = oo_; 
save('./results./bio.mat', 'bio');

%%%%%%%%%%%%%%%%%%%%%
% 脉冲反应分析      %
%%%%%%%%%%%%%%%%%%%%%
clear; 
close all; 
clc;

% 加载结果
load('./results./bo.mat');
load('./results./bio.mat');
load('./results./spo.mat');
% 该为基准模型求解结果，读者应根据自己的情形修改地址
load('C:\Users\DanielDeng_Pro\OneDrive\文档\Papers\025_DSGE_Model_Theory_and_Bayesian_Estimation\Dynamic_Stochastic_General_Equilibrium_Model\code\chapter3\results_sec./lo.mat');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 图5.4：价格黏性 vs 价格弹性
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
T = 30; x = 1:T; fsize = 12; 
h0 = figure;
set(h0, 'unit', 'centimeters', 'position', [2 2 14 8]);

subplot(2, 3, 1)
plot(x, bo.irfs.y_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot(x, lo.irfs.y_etaa(x)*100, 'Color', [0.4,0.4,0.4], 'Linestyle', '-.', 'LineWidth', 1);
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$y_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(2, 3, 2)
plot(x, bo.irfs.c_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot(x, lo.irfs.c_etaa(x)*100, 'Color', [0.4,0.4,0.4], 'Linestyle', '-.', 'LineWidth', 1);
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$c_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(2, 3, 3)
plot(x, bo.irfs.n_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot(x, lo.irfs.n_etaa(x)*100, 'Color', [0.4,0.4,0.4], 'Linestyle', '-.', 'LineWidth', 1);
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$n_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(2, 3, 4)
plot(x, bo.irfs.pi_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot(x, -bo.irfs.a_etaa(x)*100, 'Color', [0.4,0.4,0.4], 'Linestyle', '-.', 'LineWidth', 1);
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$\pi_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(2, 3, 5)
plot(x, bo.irfs.w_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot(x, lo.irfs.w_etaa(x)*100, 'Color', [0.4,0.4,0.4], 'Linestyle', '-.', 'LineWidth', 1);
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$\hat{w}_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(2, 3, 6)
plot(x, bo.irfs.r_etaa(x)*100 - bo.irfs.pi_etaa(x+1)*100, 'k-', 'LineWidth', 1);
hold on;
plot(x, lo.irfs.r_etaa(x)*100, 'Color', [0.4,0.4,0.4], 'Linestyle', '-.', 'LineWidth', 1);
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$\hat{r}_t$', 'interpreter', 'latex', 'FontSize', fsize);

legend('$\theta=0.75$', '$\theta=0.00$', 'interpreter', 'latex', ...
    'position', [0.32, 0.00, 0.40, 0.05], 'orientation', 'horizontal', 'Fontsize', fsize);
legend('boxoff')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 图5.5：松货币政策 vs 严货币政策
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
T = 30; x = 1:T; fsize = 12; 
h0 = figure;
set(h0, 'unit', 'centimeters', 'position', [2 2 14 8]);

subplot(2, 3, 1)
plot(x, bo.irfs.y_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot(x, lo.irfs.y_etaa(x)*100, 'Color', [0.4,0.4,0.4], 'Linestyle', '-.', 'LineWidth', 1);
plot(x, spo.irfs.y_etaa(x)*100, 'Color', [0.6,0.6,0.6], 'Linestyle', '--', 'LineWidth', 1);
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$y_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(2, 3, 2)
plot(x, bo.irfs.c_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot(x, lo.irfs.c_etaa(x)*100, 'Color', [0.4,0.4,0.4], 'Linestyle', '-.', 'LineWidth', 1);
plot(x, spo.irfs.c_etaa(x)*100, 'Color', [0.6,0.6,0.6], 'Linestyle', '--', 'LineWidth', 1);
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$c_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(2, 3, 3)
plot(x, bo.irfs.n_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot(x, lo.irfs.n_etaa(x)*100, 'Color', [0.4,0.4,0.4], 'Linestyle', '-.', 'LineWidth', 1);
plot(x, spo.irfs.n_etaa(x)*100, 'Color', [0.6,0.6,0.6], 'Linestyle', '--', 'LineWidth', 1);
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$n_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(2, 3, 4)
plot(x, bo.irfs.pi_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot(x, -bo.irfs.a_etaa(x)*100, 'Color', [0.4,0.4,0.4], 'Linestyle', '-.', 'LineWidth', 1);
plot(x, spo.irfs.pi_etaa(x)*100, 'Color', [0.6,0.6,0.6], 'Linestyle', '--', 'LineWidth', 1);
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$\pi_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(2, 3, 5)
plot(x, bo.irfs.w_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot(x, lo.irfs.w_etaa(x)*100, 'Color', [0.4,0.4,0.4], 'Linestyle', '-.', 'LineWidth', 1);
plot(x, spo.irfs.w_etaa(x)*100, 'Color', [0.6,0.6,0.6], 'Linestyle', '--', 'LineWidth', 1);
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$\hat{w}_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(2, 3, 6)
plot(x, bo.irfs.r_etaa(x)*100 - bo.irfs.pi_etaa(x+1)*100, 'k-', 'LineWidth', 1);
hold on;
plot(x, lo.irfs.r_etaa(x)*100, 'Color', [0.4,0.4,0.4], 'Linestyle', '-.', 'LineWidth', 1);
plot(x, spo.irfs.r_etaa(x)*100 - spo.irfs.pi_etaa(x+1)*100, 'Color', [0.6,0.6,0.6], 'Linestyle', '--', 'LineWidth', 1);
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$\hat{r}_t$', 'interpreter', 'latex', 'FontSize', fsize);

legend('$\theta=0.75\&\phi_\pi=1.5$', '$\theta=0.00$', '$\theta=0.75\&\phi_\pi=20$', 'interpreter', 'latex', ...
    'position', [0.32, 0.00, 0.40, 0.05], 'orientation', 'horizontal', 'Fontsize', fsize);
legend('boxoff')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 图5.7：无指数化调整 vs 价格指数化调整
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
T = 30; x = 1:T; fsize = 12; 
h0 = figure;
set(h0, 'unit', 'centimeters', 'position', [2 2 14 8]);

subplot(2, 3, 1)
plot(x, bo.irfs.y_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot(x, bio.irfs.y_etaa(x)*100, 'Color', [0.4,0.4,0.4], 'Linestyle', '-.', 'LineWidth', 1);
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$y_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(2, 3, 2)
plot(x, bo.irfs.c_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot(x, bio.irfs.c_etaa(x)*100, 'Color', [0.4,0.4,0.4], 'Linestyle', '-.', 'LineWidth', 1);
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$c_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(2, 3, 3)
plot(x, bo.irfs.n_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot(x, bio.irfs.n_etaa(x)*100, 'Color', [0.4,0.4,0.4], 'Linestyle', '-.', 'LineWidth', 1);
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$n_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(2, 3, 4)
plot(x, bo.irfs.pi_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot(x, bio.irfs.pi_etaa(x)*100, 'Color', [0.4,0.4,0.4], 'Linestyle', '-.', 'LineWidth', 1);
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$\pi_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(2, 3, 5)
plot(x, bo.irfs.w_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot(x, bio.irfs.w_etaa(x)*100, 'Color', [0.4,0.4,0.4], 'Linestyle', '-.', 'LineWidth', 1);
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$\hat{w}_t$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(2, 3, 6)
plot(x, bo.irfs.r_etaa(x)*100, 'k-', 'LineWidth', 1);
hold on;
plot(x, bio.irfs.r_etaa(x)*100, 'Color', [0.4,0.4,0.4], 'Linestyle', '-.', 'LineWidth', 1);
hold off;
ylabel('(%)', 'FontSize', fsize);
xlim([1, T]);
title('$r_t$', 'interpreter', 'latex', 'FontSize', fsize);

legend('$\gamma_p=0.00$', '$\gamma_p=0.73$', 'interpreter', 'latex', ...
    'position', [0.32, 0.00, 0.40, 0.05], 'orientation', 'horizontal', 'Fontsize', fsize);
legend('boxoff')



%%%%%%%%%%%%%%%%%%%%%%%%
% 矩分析       
%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all;
clc; 

% 加载数据
load('./results./bo.mat');
load('./results./spo.mat');
load('./results./bm.mat');

% 提取变量位置信息
ypos = strmatch('y',    bm.endo_names,  'exact');
cpos = strmatch('c',    bm.endo_names,  'exact');
npos = strmatch('n',    bm.endo_names,  'exact');
ppos = strmatch('pi',    bm.endo_names,  'exact');
wpos = strmatch('w',    bm.endo_names,  'exact');
rpos = strmatch('r',    bm.endo_names,  'exact');
apos = strmatch('a',    bm.endo_names,  'exact');
yposg= strmatch('ytilde',    bm.endo_names,  'exact');

%%%%%%%%%%%%%%%%%%%%%%%%%
% 政策方程和转移议程系数
%%%%%%%%%%%%%%%%%%%%%%%%%
PF = round([bo.dr.ys(ypos), bo.dr.ghx(bo.dr.inv_order_var(ypos),:), bo.dr.ghu(bo.dr.inv_order_var(ypos));
    bo.dr.ys(cpos), bo.dr.ghx(bo.dr.inv_order_var(cpos),:), bo.dr.ghu(bo.dr.inv_order_var(cpos));
    bo.dr.ys(npos), bo.dr.ghx(bo.dr.inv_order_var(npos),:), bo.dr.ghu(bo.dr.inv_order_var(npos));
    bo.dr.ys(ppos), bo.dr.ghx(bo.dr.inv_order_var(ppos),:), bo.dr.ghu(bo.dr.inv_order_var(ppos));
    bo.dr.ys(wpos), bo.dr.ghx(bo.dr.inv_order_var(wpos),:), bo.dr.ghu(bo.dr.inv_order_var(wpos));
    bo.dr.ys(rpos), bo.dr.ghx(bo.dr.inv_order_var(rpos),:), bo.dr.ghu(bo.dr.inv_order_var(rpos));
    bo.dr.ys(apos), bo.dr.ghx(bo.dr.inv_order_var(apos),:), bo.dr.ghu(bo.dr.inv_order_var(apos))], 3);

%%%%%%%%%%%%%%%%%%%
% 表5.7：标准差
%%%%%%%%%%%%%%%%%%%
Vol = round(sqrt([%
    bo.var(ypos, ypos), bo.var(yposg, yposg), bo.var(cpos, cpos), bo.var(npos, npos), ...
    NaN, bo.var(wpos, wpos), bo.var(ppos, ppos), bo.var(rpos, rpos);
    spo.var(ypos, ypos), spo.var(yposg, yposg), spo.var(cpos, cpos), spo.var(npos, npos), ...
    NaN, spo.var(wpos, wpos), spo.var(ppos, ppos), spo.var(rpos, rpos)])*100, 3);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 表5.8：与产出相关系数
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Cor = round([1, bo.var(ypos, yposg)/sqrt(bo.var(ypos, ypos)*bo.var(yposg, yposg)), ... 
    bo.var(ypos, cpos)/sqrt(bo.var(ypos, ypos)*bo.var(cpos, cpos)), ...
    bo.var(ypos, npos)/sqrt(bo.var(ypos, ypos)*bo.var(npos, npos)),... 
    bo.var(ypos, wpos)/sqrt(bo.var(ypos, ypos)*bo.var(wpos, wpos)),...
    bo.var(ypos, ppos)/sqrt(bo.var(ypos, ypos)*bo.var(ppos, ppos)), ...
    bo.var(ypos, rpos)/sqrt(bo.var(ypos, ypos)*bo.var(rpos, rpos));
    1 spo.var(ypos, yposg)/sqrt(spo.var(ypos, ypos)*spo.var(yposg, yposg)), ...
    spo.var(ypos, cpos)/sqrt(spo.var(ypos, ypos)*spo.var(cpos, cpos)), ...
    spo.var(ypos, npos)/sqrt(spo.var(ypos, ypos)*spo.var(npos, npos)),... 
    spo.var(ypos, wpos)/sqrt(spo.var(ypos, ypos)*spo.var(wpos, wpos)),...
    spo.var(ypos, ppos)/sqrt(spo.var(ypos, ypos)*spo.var(ppos, ppos)), ...
    spo.var(ypos, rpos)/sqrt(spo.var(ypos, ypos)*spo.var(rpos, rpos))], 3);

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 表5.9：一阶自相关系数
%%%%%%%%%%%%%%%%%%%%%%%%%%%
Autocor = round([bo.autocorr{1, 1}(ypos, ypos), bo.autocorr{1, 1}(yposg, yposg), ...
    bo.autocorr{1, 1}(cpos, cpos), bo.autocorr{1, 1}(npos, npos), bo.autocorr{1, 1}(wpos, wpos),... 
    bo.autocorr{1, 1}(ppos, ppos), bo.autocorr{1, 1}(rpos, rpos);
    spo.autocorr{1, 1}(ypos, ypos), spo.autocorr{1, 1}(yposg, yposg), ...
    spo.autocorr{1, 1}(cpos, cpos), spo.autocorr{1, 1}(npos, npos), spo.autocorr{1, 1}(wpos, wpos),... 
    spo.autocorr{1, 1}(ppos, ppos), spo.autocorr{1, 1}(rpos, rpos)], 3);

save('./results./Mean.mat', 'Mean');
save('./results./Vol.mat', 'Vol');
save('./results./Cor.mat', 'Cor');
save('./results./Autocor.mat', 'Autocor');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 价格指数化调整的动态影响 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all;
clc; 

% 给定货币政策参数
phipi = 1.5; timer = 0;

% 指数化调整系数逐步从0.01增加至0.99，分别求解模型
for ii = 1:99
    % 设定指数化调整系数的值
    gap = ii/100;
    % 求解模型
    dynare pricesticky -Dindex=1;
    % 提取参数值
    ypos = strmatch('y',    M_.endo_names,  'exact');
    cpos = strmatch('c',    M_.endo_names,  'exact');
    npos = strmatch('n',    M_.endo_names,  'exact');
    ppos = strmatch('pi',    M_.endo_names,  'exact');
    wpos = strmatch('w',    M_.endo_names,  'exact');
    rpos = strmatch('r',    M_.endo_names,  'exact');
    apos = strmatch('a',    M_.endo_names,  'exact');
    yposg= strmatch('ytilde',    M_.endo_names,  'exact');
    % 计算标准差
    Vol(ii,:) = round(sqrt([%
        oo_.var(ypos, ypos), oo_.var(yposg, yposg), oo_.var(cpos, cpos), oo_.var(npos, npos), ...
        oo_.var(wpos, wpos), oo_.var(ppos, ppos), oo_.var(rpos, rpos)])*100, 3);
    % 计算与产出相关系数
    Cor(ii,:) = round([1, oo_.var(ypos, yposg)/sqrt(oo_.var(ypos, ypos)*oo_.var(yposg, yposg)), ... 
        oo_.var(ypos, cpos)/sqrt(oo_.var(ypos, ypos)*oo_.var(cpos, cpos)), ...
        oo_.var(ypos, npos)/sqrt(oo_.var(ypos, ypos)*oo_.var(npos, npos)),... 
        oo_.var(ypos, wpos)/sqrt(oo_.var(ypos, ypos)*oo_.var(wpos, wpos)),...
        oo_.var(ypos, ppos)/sqrt(oo_.var(ypos, ypos)*oo_.var(ppos, ppos)), ...
        oo_.var(ypos, rpos)/sqrt(oo_.var(ypos, ypos)*oo_.var(rpos, rpos))], 3);
    % 计算一阶自相关系数
    Autocor(ii,:) = round([oo_.autocorr{1, 1}(ypos, ypos), oo_.autocorr{1, 1}(yposg, yposg), ...
        oo_.autocorr{1, 1}(cpos, cpos), oo_.autocorr{1, 1}(npos, npos), oo_.autocorr{1, 1}(wpos, wpos),... 
        oo_.autocorr{1, 1}(ppos, ppos), oo_.autocorr{1, 1}(rpos, rpos)], 3);
    timer = timer + 1
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 图5.8：指数化调整与变量标准差
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x = 0.01:0.01:0.99; fsize = 12; 
h0 = figure;
set(h0, 'unit', 'centimeters', 'position', [2 2 10 8]);
subplot(2,2,1); plot(x, Vol(:,1), 'k-', 'LineWidth', 1);
xlim([0, 1]);
title('$std(y_t)$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(2,2,2); plot(x, Vol(:,4), 'k-', 'LineWidth', 1);
xlim([0, 1]);
title('$std(n_t)$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(2,2,3); plot(x, Vol(:,5), 'k-', 'LineWidth', 1);
xlim([0, 1]); xlabel('$\gamma_p$', 'interpreter', 'latex', 'FontSize', fsize);
title('$std(\hat{w}_t)$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(2,2,4); plot(x, Vol(:,6), 'k-', 'LineWidth', 1);
xlim([0, 1]); xlabel('$\gamma_p$', 'interpreter', 'latex', 'FontSize', fsize);
title('$std(\pi_t)$', 'interpreter', 'latex', 'FontSize', fsize);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 图5.9：指数化调整与相关系数
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x = 0.01:0.01:0.99; fsize = 12; 
h0 = figure;
set(h0, 'unit', 'centimeters', 'position', [2 2 14 4]);

subplot(1,3,1); plot(x, Cor(:,4), 'k-', 'LineWidth', 1);
xlim([0, 1]);
title('$cor(n_t,y_t)$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(1,3,2); plot(x, Cor(:,5), 'k-', 'LineWidth', 1);
xlim([0, 1]); xlabel('$\gamma_p$', 'interpreter', 'latex', 'FontSize', fsize);
title('$cor(\hat{w}_t,y_t)$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(1,3,3); plot(x, Cor(:,6), 'k-', 'LineWidth', 1);
xlim([0, 1]); xlabel('$\gamma_p$', 'interpreter', 'latex', 'FontSize', fsize);
title('$cor(\pi_t,y_t)$', 'interpreter', 'latex', 'FontSize', fsize);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 图5.10：指数化调整与自相关系数
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
x = 0.01:0.01:0.99; fsize = 12; 
h0 = figure;
set(h0, 'unit', 'centimeters', 'position', [2 2 10 8]);

subplot(2,2,1); plot(x, Autocor(:,1), 'k-', 'LineWidth', 1);
xlim([0, 1]);
title('$\rho_{y_t,y_{t-1}}$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(2,2,2); plot(x, Autocor(:,4), 'k-', 'LineWidth', 1);
xlim([0, 1]);
title('$\rho_{n_t,n_{t-1}}$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(2,2,3); plot(x, Autocor(:,5), 'k-', 'LineWidth', 1);
xlim([0, 1]); xlabel('$\gamma_p$', 'interpreter', 'latex', 'FontSize', fsize);
title('$\rho_{\hat{w}_t,\hat{w}_{t-1}}$', 'interpreter', 'latex', 'FontSize', fsize);

subplot(2,2,4); plot(x, Autocor(:,6), 'k-', 'LineWidth', 1);
xlim([0, 1]); xlabel('$\gamma_p$', 'interpreter', 'latex', 'FontSize', fsize);
title('$\rho_{\pi_t,\pi_{t-1}}$', 'interpreter', 'latex', 'FontSize', fsize);

