%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 两件任务：                         %
% （1）theta和thetap之间的关系       %
% （2）模拟产品价格走势              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 作者: Deng, Guichuan               %
% 邮箱: denggch@mail.sysu.edu.cn     %
% 最新更新时间: 2026/10/12           %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 图5.2：theta和thetap之间的关系     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; close all; clc;

bet = 0.98; tht = 0.1:0.05:0.9; eps1 = 10; 
for ii = 1:length(tht)
    thep1(ii) = tht(ii)*(eps1 - 1)/((1-tht(ii))*(1-bet*tht(ii)));
end

eps2 = 5; 
for ii = 1:length(tht)
    thep2(ii) = tht(ii)*(eps2 - 1)/((1-tht(ii))*(1-bet*tht(ii)));
end

% 绘图
fsize = 12;
h0 = figure 
set(h0, 'Units','centimeters','Position', [2 2 12 8]);
plot(tht, thep1, 'Color', [0,0,0], 'LineStyle', '-', ...
    'LineWidth', 1.0, 'Marker', '^')
hold on
plot(tht, thep2, 'Color', [0,0,0], 'LineStyle', '--', ...
    'LineWidth', 1.0, 'Marker', 'o')
hold off
xlim([tht(1), tht(end)]);
xlabel('$\theta$', 'interpreter', 'latex', 'Fontsize', 12)
ylabel('$\theta_p$', 'interpreter', 'latex', 'Fontsize', 12)

legend('$\epsilon=10$', '$\epsilon=5$', 'interpreter', 'latex', ...
    'Fontsize', 12, 'position', [0.3, 0.6, 0.1, 0.25]);
legend('boxoff')



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 图5.3：模拟产品价格走势     %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; clc; close all;
T = 500; siga = 0.01; rho = 0.88;
etaa = normrnd(0, siga, [1, T]);
a = zeros([1, T+1]);
p = zeros([1, T+1]);
for ii = 1:T
    a(ii+1) = rho*a(ii) + etaa(ii);
    p(ii+1) = p(ii) + a(ii+1);
end

fsize = 12; t = 1:T;
h0 = figure; set(h0, 'Units','centimeters','Position', [2 2 12 8]);
subplot(3, 1, 1)
plot(t, etaa, 'Color', [0,0,0], 'LineStyle', '-', 'LineWidth', 1.0);
xlim([1, T]);
ylabel('$\eta_t^a$', 'interpreter', 'latex', 'Fontsize', 12)

subplot(3, 1, 2)
plot(t, a(t+1), 'Color', [0,0,0], 'LineStyle', '-', 'LineWidth', 1.0);
xlim([1, T]);
ylabel('$a_t$', 'interpreter', 'latex', 'Fontsize', 12)

subplot(3, 1, 3)
plot(t, p(t+1), 'Color', [0,0,0], 'LineStyle', '-', 'LineWidth', 1.0);
hold on;
plot([0, T], [0, 0], 'Color', [0.3,0.3,0.3], 'LineStyle', '--', 'LineWidth', 1.5);
hold off;
xlim([1, T]);
ylabel('$p_t$', 'interpreter', 'latex', 'Fontsize', 12)
xlabel('时期', 'Fontname', 'kaishu', 'Fontsize', 12)
legend('价格完全弹性', '价格完全黏性', 'position', [0.21, 0.21, 0.15, 0.1], ...
    'Fontname', 'kaishu', 'Fontsize', 10)
legend('boxoff')


