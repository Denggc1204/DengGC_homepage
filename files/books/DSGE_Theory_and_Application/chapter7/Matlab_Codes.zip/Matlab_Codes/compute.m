%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 该函数用于求解模型稳态值
% 输入：x, (xi1, C1, Cst1) 的均衡值
%      s, 1 表示 PCP， 其他表示 LCP
%      para, 参数值(Y1 Yst1 PH0 PF0 PHst0 PFst0 eta)
% 输出：err                          
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 作者: Deng, Guichuan             
% 邮箱: denggch@mail.sysu.edu.cn   
% 最新更新时间: 2026/10/15         
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function err = compute(x, s, para)
Y1 = para(1);
Yst1 = para(2);
PH0 = para(3); 
PF0 = para(4); 
PHst0 = para(5); 
PFst0 = para(6); 
eta = para(7);
PH1 = PH0; 
PFst1 = PFst0; 
xi1 = x(1); 
C1 = x(2); 
Cst1 = x(3);
if eta == 1
    if s == 1
        PHst1 = PH1/xi1; PF1 = PFst0*xi1;
        P1 = PH1^(1/2) * PF1^(1/2);
        Pst1 = PHst1^(1/2) * PFst1^(1/2);
        CH1 = 0.5*P1/PH1*C1; CF1 = 0.5*P1/PF1*C1;
        CHst1 = 0.5*Pst1/PHst1*Cst1; CFst1 = 0.5*Pst1/PFst1*Cst1;
    else
        PHst1 = PHst0; PF1 = PF0;
        P1 = PH1^0.5 * PF1^0.5;
        Pst1 = PHst1^0.5 * PFst1^0.5;
        CH1 = 0.5*P1/PH1*C1; CF1 = 0.5*P1/PF1*C1;
        CHst1 = 0.5*Pst1/PHst1*Cst1; CFst1 = 0.5*Pst1/PFst1*Cst1;
    end
else
    if s == 1
        PHst1 = PH1/xi1; PF1 = PFst0*xi1;
        P1 = (0.5*PH1^(1-eta) + 0.5*PF1^(1-eta))^(1/(1-eta));
        Pst1 = (0.5*PHst1^(1-eta) + 0.5*PFst1^(1-eta))^(1/(1-eta));
        CH1 = 0.5*(PH1/P1)^(-eta)*C1; CF1 = 0.5*(PF1/P1)^(-eta)*C1;
        CHst1 = 0.5*(PHst1/Pst1)^(-eta)*Cst1; CFst1 = 0.5*(PFst1/Pst1)^(-eta)*Cst1;
    else
        PHst1 = PHst0; PF1 = PF0;
        P1 = (0.5*PH1^(1-eta) + 0.5*PF1^(1-eta))^(1/(1-eta));
        Pst1 = (0.5*PHst1^(1-eta) + 0.5*PFst1^(1-eta))^(1/(1-eta));
        CH1 = 0.5*(PH1/P1)^(-eta)*C1; CF1 = 0.5*(PF1/P1)^(-eta)*C1;
        CHst1 = 0.5*(PHst1/Pst1)^(-eta)*Cst1; CFst1 = 0.5*(PFst1/Pst1)^(-eta)*Cst1;
    end
end
ERR1 = Y1 - (CH1 + CHst1);
ERR2 = Yst1 - (CF1 + CFst1);
ERR3 = PF1*CF1 - xi1*PHst1*CHst1;
err = [ERR1 ERR2 ERR3];
