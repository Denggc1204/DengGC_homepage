%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 第7章：求解两国对称 DSGE 模型，并分析本土偏好和
% 定价货币等经济均衡的影响
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 作者: Deng, Guichuan                     
% 邮箱: denggch@mail.sysu.edu.cn          
% 最新更新时间: 2026/10/15               
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% 表7.5： 小模型
%%%%%%%%%%%%%%%%%%%%%%%%%%
% （1）冲击发生前的经济状态
%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all; 
clc;

% 价格与销量
PH = 5000; 
PA = 5000; 
CH = 100; 
CA = 100;
M = PH*CH + PA*CA; 

% 参数值
alp = 0.5; 
eta = 2.5;

% CES 加总以及需求
P = ((1-alp)*PH^(1-eta) + alp*PA^(1-eta))^(1/(1-eta));
C = P^(-eta)*((1-alp)*PH^(1-eta) + alp*PA^(1-eta))^(-1)*M;
CH = (1-alp)*(PH/P)^(-eta)*C;
CA = alp*(PA/P)^(-eta)*C;
Pst = ((1-alp)*PA^(1-eta) + alp*PH^(1-eta))^(1/(1-eta));
Cst = Pst^(-eta)*((1-alp)*PA^(1-eta) + alp*PH^(1-eta))^(-1)*M;
CAst = (1-alp)*(PA/Pst)^(-eta)*Cst;
CHst = alp*(PH/Pst)^(-eta)*Cst;
Q = Pst/P; 
S = PA/PH;

% 汇总
[CH CA C P CHst CAst Cst Pst Q S];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% （2）冲击发生后的经济均衡
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%
% （2.1）无本土偏好的情形
%%%%%%%%%%%%%%%%%%%%%%%%%%%
% （2.1.1）本国生产率冲击
clear; 
close all; 
clc;

PH = 4500; 
PA = 5000; 
M = 1000000; 

% 本土偏好
alp = 0.5; 
eta = 2.5;
P = ((1-alp)*PH^(1-eta) + alp*PA^(1-eta))^(1/(1-eta));
C = P^(-eta)*((1-alp)*PH^(1-eta) + alp*PA^(1-eta))^(-1)*M;
CH = (1-alp)*(PH/P)^(-eta)*C;
CA = alp*(PA/P)^(-eta)*C;
Pst = ((1-alp)*PA^(1-eta) + alp*PH^(1-eta))^(1/(1-eta));
Cst = Pst^(-eta)*((1-alp)*PA^(1-eta) + alp*PH^(1-eta))^(-1)*M;
CAst = (1-alp)*(PA/Pst)^(-eta)*Cst;
CHst = alp*(PH/Pst)^(-eta)*Cst;
Q = Pst/P; 
S = PA/PH;
[CH CA C P CHst CAst Cst Pst Q S];

% （2.1.2）外国生产率冲击
clear; 
close all; 
clc;

PH = 5000; 
PA = 4500; 
M = 1000000; 

% 本土偏好
alp = 0.5; 
eta = 2.5;
P = ((1-alp)*PH^(1-eta) + alp*PA^(1-eta))^(1/(1-eta));
C = P^(-eta)*((1-alp)*PH^(1-eta) + alp*PA^(1-eta))^(-1)*M;
CH = (1-alp)*(PH/P)^(-eta)*C;
CA = alp*(PA/P)^(-eta)*C;
Pst = ((1-alp)*PA^(1-eta) + alp*PH^(1-eta))^(1/(1-eta));
Cst = Pst^(-eta)*((1-alp)*PA^(1-eta) + alp*PH^(1-eta))^(-1)*M;
CAst = (1-alp)*(PA/Pst)^(-eta)*Cst;
CHst = alp*(PH/Pst)^(-eta)*Cst;
Q = Pst/P; 
S = PA/PH;

[CH CA C P CHst CAst Cst Pst Q S];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% （2.2）具有本土偏好的情形
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% （2.2.1）本国生产率冲击
clear; 
close all; 
clc;

PH = 4500; 
PA = 5000; 
M = 1000000; 

% 本土偏好
alp = 0.4;  
eta = 2.5;
P = ((1-alp)*PH^(1-eta) + alp*PA^(1-eta))^(1/(1-eta));
C = P^(-eta)*((1-alp)*PH^(1-eta) + alp*PA^(1-eta))^(-1)*M;
CH = (1-alp)*(PH/P)^(-eta)*C;
CA = alp*(PA/P)^(-eta)*C;
Pst = ((1-alp)*PA^(1-eta) + alp*PH^(1-eta))^(1/(1-eta));
Cst = Pst^(-eta)*((1-alp)*PA^(1-eta) + alp*PH^(1-eta))^(-1)*M;
CAst = (1-alp)*(PA/Pst)^(-eta)*Cst;
CHst = alp*(PH/Pst)^(-eta)*Cst;
Q = Pst/P; 
S = PA/PH;

[CH CA C P CHst CAst Cst Pst Q S];

% （2.2.2）外国生产率冲击
clear; 
close all; 
clc;

PH = 5000; 
PA = 4500; 
M = 1000000; 

% 本土偏好
alp = 0.4; 
eta = 2.5;
P = ((1-alp)*PH^(1-eta) + alp*PA^(1-eta))^(1/(1-eta));
C = P^(-eta)*((1-alp)*PH^(1-eta) + alp*PA^(1-eta))^(-1)*M;
CH = (1-alp)*(PH/P)^(-eta)*C;
CA = alp*(PA/P)^(-eta)*C;
Pst = ((1-alp)*PA^(1-eta) + alp*PH^(1-eta))^(1/(1-eta));
Cst = Pst^(-eta)*((1-alp)*PA^(1-eta) + alp*PH^(1-eta))^(-1)*M;
CAst = (1-alp)*(PA/Pst)^(-eta)*Cst;
CHst = alp*(PH/Pst)^(-eta)*Cst;
Q = Pst/P; 
S = PA/PH;

[CH CA C P CHst CAst Cst Pst Q S];

%%%%%%%%%%%%%%%%%%%%%
% 分解
%%%%%%%%%%%%%%%%%%%%%
141.61 - 100 - (119.88 - 100)
4684.4 - 5000 - (4733.6 - 5000)

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 小模型解释定价货币的作用
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all; 
clc;

%%%%%%%%%%%%%%%%%
% 初始值
%%%%%%%%%%%%%%%%%
PH0 = 5000; 
PF0 = 5000; 
PFst0 = 1000; 
PHst0 = 1000;
Y0 = 200; 
Yst0 = 200; 
xi0 = 5; 
C0 = 100; 
Cst0 = 100;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ---------- 1. 单位替代弹性  --------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eta = 1; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% （1）生产商货币定价: PCP
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%
% （1.1）本国生产率冲击
%%%%%%%%%%%%%%%%%%%%%%%%%
Y1 = 220; 
Yst1 = 200; 
para = [Y1 Yst1 PH0 PF0 PHst0 PFst0 eta];
x0 = [xi0 C0 Cst0];
options     =    optimoptions('fsolve', 'Display', 'iter');
[xx, fval]  =    fsolve(@(x) compute(x, 1, para), x0, options); 
xi1 = xx(1); 
C1 = xx(2); 
Cst1 = xx(3);
PH1 = PH0; 
PFst1 = PFst0; 
PHst1 = PH1/xi1; 
PF1 = PFst0*xi1;
P1 = PH1^0.5 * PF1^0.5; 
Pst1 = PHst1^0.5 * PFst1^0.5;
CH1 = 0.5*P1/PH1*C1; 
CF1 = 0.5*P1/PF1*C1;
CHst1 = 0.5*Pst1/PHst1*Cst1; 
CFst1 = 0.5*Pst1/PFst1*Cst1;
Q1 = xi1*Pst1/P1; 
S1 = PF1/PH1;

% 汇总并取两位有效数字
round([CH1, CF1, CFst1, CHst1, C1, Cst1, PH1, PF1, PHst1, PFst1, P1, Pst1, Q1, S1], 2);

%%%%%%%%%%%%%%%%%%%%%%%%%%
% （1.2）外国生产率冲击
%%%%%%%%%%%%%%%%%%%%%%%%%%
Y1 = 200; 
Yst1 = 220; 
para = [Y1 Yst1 PH0 PF0 PHst0 PFst0 eta];
x0 = [xi0 C0 Cst0];
options     =    optimoptions('fsolve', 'Display', 'iter');
[xx, fval]  =    fsolve(@(x) compute(x, 1, para), x0, options); 
xi1 = xx(1); 
C1 = xx(2); 
Cst1 = xx(3);
PH1 = PH0; 
PFst1 = PFst0; 
PHst1 = PH1/xi1; 
PF1 = PFst0*xi1;
P1 = PH1^0.5 * PF1^0.5; 
Pst1 = PHst1^0.5 * PFst1^0.5;
CH1 = 0.5*P1/PH1*C1; 
CF1 = 0.5*P1/PF1*C1;
CHst1 = 0.5*Pst1/PHst1*Cst1; 
CFst1 = 0.5*Pst1/PFst1*Cst1;
Q1 = xi1*Pst1/P1; 
S1 = PF1/PH1;

% 汇总并取两位有效数字
round([CH1, CF1, CFst1, CHst1, C1, Cst1, PH1, PF1, PHst1, PFst1, P1, Pst1, Q1, S1], 2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% （2）当地货币定价: PCP
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%
% （2.1）本国生产率冲击
%%%%%%%%%%%%%%%%%%%%%%%%
Y1 = 220; 
Yst1 = 200; 
para = [Y1 Yst1 PH0 PF0 PHst0 PFst0 eta];
x0 = [xi0 C0 Cst0];
options     =    optimoptions('fsolve', 'Display', 'iter');
[xx, fval]  =    fsolve(@(x) compute(x, 2, para), x0, options); 
xi1 = xx(1); 
C1 = xx(2); 
Cst1 = xx(3);
PH1 = PH0; 
PFst1 = PFst0; 
PHst1 = PH1/xi1; 
PF1 = PFst0*xi1;
P1 = PH1^0.5 * PF1^0.5; 
Pst1 = PHst1^0.5 * PFst1^0.5;
CH1 = 0.5*P1/PH1*C1; 
CF1 = 0.5*P1/PF1*C1;
CHst1 = 0.5*Pst1/PHst1*Cst1; 
CFst1 = 0.5*Pst1/PFst1*Cst1;
Q1 = xi1*Pst1/P1;
S1 = PF1/PH1;

% 汇总并取两位有效数字
round([CH1, CF1, CFst1, CHst1, C1, Cst1, PH1, PF1, PHst1, PFst1, P1, Pst1, Q1, S1], 2);

%%%%%%%%%%%%%%%%%%%%%%%%
% （2.2）外国生产率冲击
%%%%%%%%%%%%%%%%%%%%%%%%
Y1 = 200; 
Yst1 = 220; 
para = [Y1 Yst1 PH0 PF0 PHst0 PFst0 eta];
x0 = [xi0 C0 Cst0];
options     =    optimoptions('fsolve', 'Display', 'iter');
[xx, fval]  =    fsolve(@(x) compute(x, 2, para), x0, options); 
xi1 = xx(1); 
C1 = xx(2); 
Cst1 = xx(3);
PH1 = PH0; 
PFst1 = PFst0; 
PHst1 = PH1/xi1; 
PF1 = PFst0*xi1;
P1 = PH1^0.5 * PF1^0.5; 
Pst1 = PHst1^0.5 * PFst1^0.5;
CH1 = 0.5*P1/PH1*C1; 
CF1 = 0.5*P1/PF1*C1;
CHst1 = 0.5*Pst1/PHst1*Cst1; 
CFst1 = 0.5*Pst1/PFst1*Cst1;
Q1 = xi1*Pst1/P1; 
S1 = PF1/PH1;

% 汇总并取两位有效数字
round([CH1, CF1, CFst1, CHst1, C1, Cst1, PH1, PF1, PHst1, PFst1, P1, Pst1, Q1, S1], 2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ---------- 2. 替代弹性富有弹性  -------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
eta = 2.5; 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% （1）本国货币定价: PCP
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%
% （1.1）本国生产率冲击
%%%%%%%%%%%%%%%%%%%%%%%%%
Y1 = 220; 
Yst1 = 200; 
para = [Y1 Yst1 PH0 PF0 PHst0 PFst0 eta];
x0 = [xi0 C0 Cst0];
options     =    optimoptions('fsolve', 'Display', 'iter');
[xx, fval]  =    fsolve(@(x) compute(x, 1, para), x0, options); 
xi1 = xx(1); 
C1 = xx(2); 
Cst1 = xx(3);
PH1 = PH0; 
PFst1 = PFst0; 
PHst1 = PH1/xi1; 
PF1 = PFst0*xi1;
P1 = (0.5*PH1^(1-eta) + 0.5*PF1^(1-eta))^(1/(1-eta));
Pst1 = (0.5*PHst1^(1-eta) + 0.5*PFst1^(1-eta))^(1/(1-eta));
CH1 = 0.5*(PH1/P1)^(-eta)*C1; 
CF1 = 0.5*(PF1/P1)^(-eta)*C1;
CHst1 = 0.5*(PHst1/Pst1)^(-eta)*Cst1; 
CFst1 = 0.5*(PFst1/Pst1)^(-eta)*Cst1;
Q1 = xi1*Pst1/P1; 
S1 = PF1/PH1;

% 汇总并取两位有效数字
round([CH1, CF1, CFst1, CHst1, C1, Cst1, PH1, PF1, PHst1, PFst1, P1, Pst1, Q1, S1], 2);

%%%%%%%%%%%%%%%%%%%%%%%%%
% （1.2）外国生产率冲击
%%%%%%%%%%%%%%%%%%%%%%%%%
Y1 = 200; 
Yst1 = 220; 
para = [Y1 Yst1 PH0 PF0 PHst0 PFst0 eta];
x0 = [xi0 C0 Cst0];
options     =    optimoptions('fsolve', 'Display', 'iter');
[xx, fval]  =    fsolve(@(x) compute(x, 1, para), x0, options); 
xi1 = xx(1); 
C1 = xx(2); 
Cst1 = xx(3);
PH1 = PH0; 
PFst1 = PFst0; 
PHst1 = PH1/xi1; 
PF1 = PFst0*xi1;
P1 = (0.5*PH1^(1-eta) + 0.5*PF1^(1-eta))^(1/(1-eta));
Pst1 = (0.5*PHst1^(1-eta) + 0.5*PFst1^(1-eta))^(1/(1-eta));
CH1 = 0.5*(PH1/P1)^(-eta)*C1; 
CF1 = 0.5*(PF1/P1)^(-eta)*C1;
CHst1 = 0.5*(PHst1/Pst1)^(-eta)*Cst1; 
CFst1 = 0.5*(PFst1/Pst1)^(-eta)*Cst1;
Q1 = xi1*Pst1/P1; 
S1 = PF1/PH1;

% 汇总并取两位有效数字
round([CH1, CF1, CFst1, CHst1, C1, Cst1, PH1, PF1, PHst1, PFst1, P1, Pst1, Q1, S1], 2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% （2）当地货币定价: LCP 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%
% （2.1）本国生产率冲击
%%%%%%%%%%%%%%%%%%%%%%%%
Y1 = 220; 
Yst1 = 200; 
para = [Y1 Yst1 PH0 PF0 PHst0 PFst0 eta];
x0 = [xi0 C0 Cst0];
options     =    optimoptions('fsolve', 'Display', 'iter');
[xx, fval]  =    fsolve(@(x) compute(x, 2, para), x0, options); 
xi1 = xx(1); 
C1 = xx(2); 
Cst1 = xx(3);
PH1 = PH0; 
PFst1 = PFst0; 
PHst1 = PHst0; 
PF1 = PF0;
P1 = (0.5*PH1^(1-eta) + 0.5*PF1^(1-eta))^(1/(1-eta));
Pst1 = (0.5*PHst1^(1-eta) + 0.5*PFst1^(1-eta))^(1/(1-eta));
CH1 = 0.5*(PH1/P1)^(-eta)*C1; 
CF1 = 0.5*(PF1/P1)^(-eta)*C1;
CHst1 = 0.5*(PHst1/Pst1)^(-eta)*Cst1; 
CFst1 = 0.5*(PFst1/Pst1)^(-eta)*Cst1;
Q1 = xi1*Pst1/P1; 
S1 = PF1/PH1;

% 汇总并取两位有效数字
round([CH1, CF1, CFst1, CHst1, C1, Cst1, PH1, PF1, PHst1, PFst1, P1, Pst1, Q1, S1], 2);

%%%%%%%%%%%%%%%%%%%%%%%%
% （2.2）外国生产率冲击
%%%%%%%%%%%%%%%%%%%%%%%%
Y1 = 200; 
Yst1 = 220; 
para = [Y1 Yst1 PH0 PF0 PHst0 PFst0 eta];
x0 = [xi0 C0 Cst0];
options     =    optimoptions('fsolve', 'Display', 'iter');
[xx, fval]  =    fsolve(@(x) compute(x, 2, para), x0, options); 
xi1 = xx(1); 
C1 = xx(2); 
Cst1 = xx(3);
PH1 = PH0; 
PFst1 = PFst0; 
PHst1 = PHst0; 
PF1 = PF0;
P1 = (0.5*PH1^(1-eta) + 0.5*PF1^(1-eta))^(1/(1-eta));
Pst1 = (0.5*PHst1^(1-eta) + 0.5*PFst1^(1-eta))^(1/(1-eta));
CH1 = 0.5*(PH1/P1)^(-eta)*C1; 
CF1 = 0.5*(PF1/P1)^(-eta)*C1;
CHst1 = 0.5*(PHst1/Pst1)^(-eta)*Cst1; 
CFst1 = 0.5*(PFst1/Pst1)^(-eta)*Cst1;
Q1 = xi1*Pst1/P1; 
S1 = PF1/PH1;

% 汇总并取两位有效数字
round([CH1, CF1, CFst1, CHst1, C1, Cst1, PH1, PF1, PHst1, PFst1, P1, Pst1, Q1, S1], 2);

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 使用 Dynare 求解两国对称 DSGE 模型并进行分析
% 两种情形：（1）定价货币的效果：PCP VS LCP
%          （2）本土偏好：alpha=0.2 vs alpha=0.5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% 新建子文件夹
mkdir('./result')

%%%%%%%%%%%%%%%%%%%%%%%%%%
% （1）定价货币的效果
%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%
% （1.1）PCP
%%%%%%%%%%%%%%%%
clear; 
close all; 
clc;

% 本土偏好参数
alp = 0.37;

% 求解和模拟
dynare two_country.mod -Dcase=1;

% 保存结果
pbo = oo_;
save('./result./pbo.mat', 'pbo');
save('./result./M_.mat', 'M_');

%%%%%%%%%%%%%%%
% （1.2）LCP
%%%%%%%%%%%%%%%
clear; 
close all; 
clc;

% 本土偏好参数
alp = 0.37;

% 求解和模拟
dynare two_country.mod -Dcase=2;

% 保存结果
lbo = oo_;
save('./result./lbo.mat', 'lbo');

%%%%%%%%%%%%%%%%%%%%%%%%%%
% （2）无本土偏好
%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%
% （2.1）PCP
%%%%%%%%%%%%%%
clear; 
close all; 
clc;

% 本土偏好参数
alp = 0.50;

% 求解和模拟
dynare two_country.mod -Dcase=1;

% 保存结果
pno = oo_;
save('./result./pno.mat', 'pno');

%%%%%%%%%%%%%%
% （2.2）LCP
%%%%%%%%%%%%%%
clear; 
close all; 
clc;

% 本土偏好参数
alp = 0.50;

% 求解和模拟
dynare two_country.mod -Dcase=2;

% 保存结果
lno = oo_;
save('./result./lno.mat', 'lno');


%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 基于求解结果展开分析：
% (1)本土偏好的影响
% (2)定价货币的影响
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all; 
clc;

% 加载数据
load('./result./pbo')  % PCP
load('./result./lbo')  % LCP
load('./result./pno')  % PCP without home bias
load('./result./lno')  % LCP without home bias

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (1) 本土偏好的影响：alpha=0.37 vs alpha=0.5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
T = 10; t = 1:T;

% 图7.1：本国生产率冲击
h0 = figure
set(h0,'Units','centimeters','Position',[2 2 14 16]);

subplot(4, 3, 1);
plot(t, pbo.irfs.y_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, pno.irfs.y_etaa(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$y_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 2);
plot(t, pbo.irfs.yst_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, pno.irfs.yst_etaa(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$y_t^\ast$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 3)
plot(t, pbo.irfs.c_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, pno.irfs.c_etaa(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$c_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 4)
plot(t, pbo.irfs.cst_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, pno.irfs.cst_etaa(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$c_t^\ast$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 5)
plot(t, pbo.irfs.piH_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, pno.irfs.piH_etaa(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$\pi_{Ht}$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 6)
plot(t, pbo.irfs.piFst_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, pno.irfs.piFst_etaa(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$\pi_{Ft}^\ast$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 7)
plot(t, pbo.irfs.pi_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, pno.irfs.pi_etaa(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$\pi_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 8)
plot(t, pbo.irfs.pist_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, pno.irfs.pist_etaa(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$\pi_t^\ast$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 9)
plot(t, pbo.irfs.q_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, pno.irfs.q_etaa(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$q_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 10)
plot(t, pbo.irfs.s_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, pno.irfs.s_etaa(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$s_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 11)
plot(t, (pbo.irfs.y_etaa(t)-pbo.irfs.yb_etaa(t))*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, (pno.irfs.y_etaa(t)-pno.irfs.yb_etaa(t))*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$\tilde{y}_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 12)
plot(t, (pbo.irfs.yst_etaa(t)-pbo.irfs.ybst_etaa(t))*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, (pno.irfs.yst_etaa(t)-pno.irfs.ybst_etaa(t))*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$\tilde{y}_t^\ast$', 'interpreter', 'latex', 'fontsize', 12)

legend({'$\alpha=0.37$', '$\alpha=0.50$'}, 'interpreter', 'latex', 'position', [0.73 0.10 0.20 0.10], ...
    'fontname', 'kaiti', 'fontsize', 10.5);
legend('boxoff');


% 图7.2：外国生产率冲击
h0 = figure
set(h0,'Units','centimeters','Position',[2 2 14 16]);
subplot(4, 3, 1);
plot(t, pbo.irfs.y_etaast(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, pno.irfs.y_etaast(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$y_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 2);
plot(t, pbo.irfs.yst_etaast(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, pno.irfs.yst_etaast(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$y_t^\ast$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 3)
plot(t, pbo.irfs.c_etaast(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, pno.irfs.c_etaast(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$c_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 4)
plot(t, pbo.irfs.cst_etaast(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, pno.irfs.cst_etaast(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$c_t^\ast$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 5)
plot(t, pbo.irfs.piH_etaast(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, pno.irfs.piH_etaast(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$\pi_{Ht}$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 6)
plot(t, pbo.irfs.piFst_etaast(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, pno.irfs.piFst_etaast(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$\pi_{Ft}^\ast$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 7)
plot(t, pbo.irfs.pi_etaast(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, pno.irfs.pi_etaast(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$\pi_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 8)
plot(t, pbo.irfs.pist_etaast(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, pno.irfs.pist_etaast(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$\pi_t^\ast$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 9)
plot(t, pbo.irfs.q_etaast(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, pno.irfs.q_etaast(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$q_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 10)
plot(t, pbo.irfs.s_etaast(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, pno.irfs.s_etaast(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$s_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 11)
plot(t, (pbo.irfs.y_etaast(t)-pbo.irfs.yb_etaast(t))*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, (pno.irfs.y_etaast(t)-pno.irfs.yb_etaast(t))*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$\tilde{y}_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 12)
plot(t, (pbo.irfs.yst_etaa(t)-pbo.irfs.ybst_etaast(t))*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, (pno.irfs.yst_etaa(t)-pno.irfs.ybst_etaast(t))*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$\tilde{y}_t^\ast$', 'interpreter', 'latex', 'fontsize', 12)

legend({'$\alpha=0.37$', '$\alpha=0.50$'}, 'interpreter', 'latex', 'position', [0.73 0.10 0.20 0.10], ...
    'fontname', 'kaiti', 'fontsize', 10.5);
legend('boxoff');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (2) 定价货币的影响：PCP vs LCP （无本土偏好）
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 图7.3：本国生产率冲击
h0 = figure
set(h0,'Units','centimeters','Position',[2 2 14 16]);

subplot(4, 3, 1);
plot(t, pno.irfs.y_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, lno.irfs.y_etaa(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$y_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 2);
plot(t, pno.irfs.yst_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, lno.irfs.yst_etaa(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$y_t^\ast$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 3)
plot(t, pno.irfs.c_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, lno.irfs.c_etaa(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$c_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 4)
plot(t, pno.irfs.cst_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, lno.irfs.cst_etaa(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$c_t^\ast$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 5)
plot(t, pno.irfs.piH_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, lno.irfs.piH_etaa(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$\pi_{Ht}$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 6)
plot(t, pno.irfs.piFst_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, lno.irfs.piFst_etaa(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$\pi_{Ft}^\ast$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 7)
plot(t, pno.irfs.pi_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, lno.irfs.pi_etaa(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$\pi_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 8)
plot(t, pno.irfs.pist_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, lno.irfs.pist_etaa(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$\pi_t^\ast$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 9)
plot(t, pno.irfs.s_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, lno.irfs.s_etaa(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$s_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 10)
plot(t, pno.irfs.a_etaa(t)*0, 'k-', 'LineWidth', 1);
hold on;
plot(t, lno.irfs.cm_etaa(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$cm_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 11)
plot(t, pno.irfs.piF_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, lno.irfs.piF_etaa(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$\pi_{Ft}$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 12)
plot(t, pno.irfs.piHst_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, lno.irfs.piHst_etaa(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$\pi_{Ht}^\ast$', 'interpreter', 'latex', 'fontsize', 12);

legend({'PCP', 'LCP'}, 'position', [0.73 0.10 0.20 0.10], ...
    'fontname', 'kaiti', 'fontsize', 10.5);
legend('boxoff');


% 图7.4：外国生产率冲击
h0 = figure
set(h0,'Units','centimeters','Position',[2 2 14 16]);
subplot(4, 3, 1);
plot(t, pno.irfs.y_etaast(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, lno.irfs.y_etaast(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$y_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 2);
plot(t, pno.irfs.yst_etaast(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, lno.irfs.yst_etaast(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$y_t^\ast$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 3)
plot(t, pno.irfs.c_etaast(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, lno.irfs.c_etaast(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$c_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 4)
plot(t, pno.irfs.cst_etaast(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, lno.irfs.cst_etaast(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$c_t^\ast$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 5)
plot(t, pno.irfs.piH_etaast(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, lno.irfs.piH_etaast(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$\pi_{Ht}$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 6)
plot(t, pno.irfs.piFst_etaast(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, lno.irfs.piFst_etaast(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$\pi_{Ft}^\ast$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 7)
plot(t, pno.irfs.pi_etaast(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, lno.irfs.pi_etaast(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$\pi_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 8)
plot(t, pno.irfs.pist_etaast(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, lno.irfs.pist_etaast(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$\pi_t^\ast$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 9)
plot(t, pno.irfs.s_etaast(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, lno.irfs.s_etaast(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$s_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 10)
plot(t, pno.irfs.a_etaast(t)*0, 'k-', 'LineWidth', 1);
hold on;
plot(t, lno.irfs.cm_etaast(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$cm_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 11)
plot(t, pno.irfs.piF_etaast(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, lno.irfs.piF_etaast(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$\pi_{Ft}$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 12)
plot(t, pno.irfs.piHst_etaast(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, lno.irfs.piHst_etaast(t)*100, 'Color', [0.5,0.5,0.5], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$\pi_{Ht}^\ast$', 'interpreter', 'latex', 'fontsize', 12);

legend({'PCP', 'LCP'}, 'position', [0.45 0.10 0.20 0.10], ...
    'fontname', 'kaiti', 'fontsize', 10.5);
legend('boxoff');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (3) 定价货币的影响：PCP vs LCP （有本土偏好）
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 3.1：本国生产率冲击
h0 = figure
set(h0,'Units','centimeters','Position',[2 2 14 16]);
subplot(4, 3, 1);
plot(t, pbo.irfs.y_etaa(t)*100, 'r--', t, lbo.irfs.y_etaa(t)*100, 'b-', 'LineWidth', 1.25);
xlim([0 T]); ylabel('%'); title('$y_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 2);
plot(t, pbo.irfs.yst_etaa(t)*100, 'r--', t, lbo.irfs.yst_etaa(t)*100, 'b-', 'LineWidth', 1.25);
xlim([0 T]); ylabel('%'); title('$y_t^\ast$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 3)
plot(t, pbo.irfs.c_etaa(t)*100, 'r--', t, lbo.irfs.c_etaa(t)*100, 'b-', 'LineWidth', 1.25);
xlim([0 T]); ylabel('%'); title('$c_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 4)
plot(t, pbo.irfs.cst_etaa(t)*100, 'r--', t, lbo.irfs.cst_etaa(t)*100, 'b-', 'LineWidth', 1.25);
xlim([0 T]); ylabel('%'); title('$c_t^\ast$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 5)
plot(t, pbo.irfs.piH_etaa(t)*100, 'r--', t, lbo.irfs.piH_etaa(t)*100, 'b-', 'LineWidth', 1.25);
xlim([0 T]); ylabel('%'); title('$\pi_{Ht}$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 6)
plot(t, pbo.irfs.piFst_etaa(t)*100, 'r--', t, lbo.irfs.piFst_etaa(t)*100, 'b-', 'LineWidth', 1.25);
xlim([0 T]); ylabel('%'); title('$\pi_{Ft}^\ast$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 7)
plot(t, pbo.irfs.pi_etaa(t)*100, 'r--', t, lbo.irfs.pi_etaa(t)*100, 'b-', 'LineWidth', 1.25);
xlim([0 T]); ylabel('%'); title('$\pi_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 8)
plot(t, pbo.irfs.pist_etaa(t)*100, 'r--', t, lbo.irfs.pist_etaa(t)*100, 'b-', 'LineWidth', 1.25);
xlim([0 T]); ylabel('%'); title('$\pi_t^\ast$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 9)
plot(t, pbo.irfs.q_etaa(t)*100, 'r--', t, lbo.irfs.q_etaa(t)*100, 'b-', 'LineWidth', 1.25);
xlim([0 T]); ylabel('%'); title('$q_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 10)
plot(t, pbo.irfs.s_etaa(t)*100, 'r--', t, lbo.irfs.s_etaa(t)*100, 'b-', 'LineWidth', 1.25);
xlim([0 T]); ylabel('%'); title('$s_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 11)
plot(t, pbo.irfs.a_etaa(t)*0, 'r--', t, lbo.irfs.cm_etaa(t)*100, 'b-', 'LineWidth', 1.25);
xlim([0 T]); ylabel('%'); title('$cm_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 12)
plot(t, (pbo.irfs.y_etaa(t)-pbo.irfs.yb_etaa(t))*100, 'r--', t, (lbo.irfs.y_etaa(t)-lbo.irfs.yb_etaa(t))*100, 'b-', 'LineWidth', 1.25);
xlim([0 T]); ylabel('%'); title('$\tilde{y}_t$', 'interpreter', 'latex', 'fontsize', 12);

legend({'PCP', 'LCP'}, 'position', [0.73 0.10 0.20 0.15], ...
    'fontname', 'kaiti', 'fontsize', 10.5);
legend('boxoff');


% 3.2：外国生产率冲击
h0 = figure
set(h0,'Units','centimeters','Position',[2 2 14 16]);
subplot(4, 3, 1);
plot(t, pbo.irfs.y_etaast(t)*100, 'r--', t, lbo.irfs.y_etaast(t)*100, 'b-', 'LineWidth', 1.25);
xlim([0 T]); ylabel('%'); title('$y_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 2);
plot(t, pbo.irfs.yst_etaast(t)*100, 'r--', t, lbo.irfs.yst_etaast(t)*100, 'b-', 'LineWidth', 1.25);
xlim([0 T]); ylabel('%'); title('$y_t^\ast$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 3)
plot(t, pbo.irfs.c_etaast(t)*100, 'r--', t, lbo.irfs.c_etaast(t)*100, 'b-', 'LineWidth', 1.25);
xlim([0 T]); ylabel('%'); title('$c_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 4)
plot(t, pbo.irfs.cst_etaast(t)*100, 'r--', t, lbo.irfs.cst_etaast(t)*100, 'b-', 'LineWidth', 1.25);
xlim([0 T]); ylabel('%'); title('$c_t^\ast$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 5)
plot(t, pbo.irfs.piH_etaast(t)*100, 'r--', t, lbo.irfs.piH_etaast(t)*100, 'b-', 'LineWidth', 1.25);
xlim([0 T]); ylabel('%'); title('$\pi_{Ht}$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 6)
plot(t, pbo.irfs.piFst_etaast(t)*100, 'r--', t, lbo.irfs.piFst_etaast(t)*100, 'b-', 'LineWidth', 1.25);
xlim([0 T]); ylabel('%'); title('$\pi_{Ft}^\ast$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 7)
plot(t, pbo.irfs.pi_etaast(t)*100, 'r--', t, lbo.irfs.pi_etaast(t)*100, 'b-', 'LineWidth', 1.25);
xlim([0 T]); ylabel('%'); title('$\pi_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 8)
plot(t, pbo.irfs.pist_etaast(t)*100, 'r--', t, lbo.irfs.pist_etaast(t)*100, 'b-', 'LineWidth', 1.25);
xlim([0 T]); ylabel('%'); title('$\pi_t^\ast$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 9)
plot(t, pbo.irfs.q_etaast(t)*100, 'r--', t, lbo.irfs.q_etaast(t)*100, 'b-', 'LineWidth', 1.25);
xlim([0 T]); ylabel('%'); title('$q_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 10)
plot(t, pbo.irfs.s_etaast(t)*100, 'r--', t, lbo.irfs.s_etaast(t)*100, 'b-', 'LineWidth', 1.25);
xlim([0 T]); ylabel('%'); title('$s_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 11)
plot(t, pbo.irfs.a_etaast(t)*0, 'r--', t, lbo.irfs.cm_etaast(t)*100, 'b-', 'LineWidth', 1.25);
xlim([0 T]); ylabel('%'); title('$cm_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(4, 3, 12)
plot(t, (pbo.irfs.y_etaast(t)-pbo.irfs.yb_etaast(t))*100, 'r--', t, (lbo.irfs.y_etaast(t)-lbo.irfs.yb_etaast(t))*100, 'b-', 'LineWidth', 1.25);
xlim([0 T]); ylabel('%'); title('$\tilde{y}_t$', 'interpreter', 'latex', 'fontsize', 12);

legend({'PCP', 'LCP'}, 'position', [0.73 0.16 0.20 0.10], ...
    'fontname', 'kaiti', 'fontsize', 10.5);
legend('boxoff');



