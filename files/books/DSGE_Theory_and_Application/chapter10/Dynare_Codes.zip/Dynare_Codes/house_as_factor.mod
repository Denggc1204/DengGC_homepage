%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 该 Mod 文件用于求解住房作为抵押物的模型
% 比较抵押融资约束如何影响经济均衡：
% （1）基准模型：无抵押融资约束
% （2）有融资约束：资本作为抵押物
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 作者: Deng, Guichuan               
% 邮箱: denggch@mail.sysu.edu.cn    
% 最新更新时间: 2026/10/14           
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

// 定义宏变量 Factor
// 如果 Factor = 1, 住房作为生产要素，默认值
// 如果 Factor = 0, 住房不作为生产要素
@#ifndef Factor
    @#define Factor = 1
@#endif



// ------------------
// 声明内生变量
// ------------------
var cs ns hs cb nb hb l y r q a w
@#if Factor == 1
   n hf
@#endif
;

// -------------
//  声明外生变量
// -------------
varexo etaa;

// ----------
// 声明参数
// ----------
parameters bts btb vph ome alp eps del rhoa siga
Ome1 Ome2 Omes mu R HB CB NB L H HS CS NS Y 
@#if Factor == 1
   N HF
@#endif
;

// --------------
// 校准参数值
// --------------
bts = 0.99;  
btb = 0.98;  
set_param_value('vph', vph);
set_param_value('ome', ome);
alp = 0.30;
eps = 4.61;  
del = 0.025; 
rhoa = 0.88;
siga = 0.01;  
mu = (eps-1)/eps; 
Ome1 = 1 - bts*(1-del);
Ome2 = 1 - btb*(1 - del) - ome*(bts - btb);
Omes = 1 + (del + ome*(1-bts))/Ome2;
R = 1/bts;
para = [bts btb vph ome alp eps del];
options = optimoptions('fsolve', 'Display', 'iter');
@#if Factor == 1
   W = (1-alp)*mu^(1/(1-alp))*(alp/Ome1)^(alp/(1-alp));
   HB = Omes^(-vph/(1+vph))*W/Ome2;
   CB = Omes^(-vph/(1+vph))*W;
   NB = Omes^(1/(1+vph));
   x0 = 148;
   [xx, fval] = fsolve(@(x) computeH(x, 2, para), x0, options);  
   H = xx;
   HF = alp*mu/(1+alp*mu)*(H - HB + CB/Ome1);
   HS = H - HB - HF;
   CS = Ome1*HS;
   Y = CS + CB;
   N = (1-alp)*mu*Y/W;
   NS = N - NB;
@#else
   HB = Omes^(-vph/(1+vph))*mu/Ome2;
   CB = Omes^(-vph/(1+vph))*mu;
   NB = Omes^(1/(1+vph));
   L = ome*bts*HB;
   x0 = 57;
   [xx, fval] = fsolve(@(x) computeH(x, 1, para), x0, options); 
   H = xx;
   HS = H - HB;
   CS = Ome1*HS;
   Y = CS + CB;
   NS = Y - NB;
@#endif
L = ome*bts*HB;

// ------------
// 声明模型
// ------------
model;
exp(cs) = exp(cs(+1) - r);
exp(cs + vph*ns) = exp(w);
exp(cb + vph*nb) = exp(w);
Ome1 * exp(cs(+1) - q - hs) = exp(r) - (1 - Ome1)*exp(q(+1) - q);
exp(r + l) = exp(q(+1) + hb);
Ome2*exp(cb(+1) - q - hb) = exp(cb(+1)-cb) - (1-del)*btb*exp(q(+1) - q) - ome*bts*exp(cb(+1) + q(+1) - cb - q - r) + ome*btb*exp(q(+1) - q);
CB*exp(cb) + HB*exp(q + hb) + R*L*exp(r(-1) + l(-1)) = mu*NB*exp(a + nb) + (1-del)*HB*exp(q + hb(-1)) + L*exp(l);
Y*exp(y) = CS*exp(cs) + CB*exp(cb);
@#if Factor == 1
   exp(y) = exp(a + alp*hf + (1-alp)*n);
   exp(n) = exp(y - w);
   Ome1*exp(y-q-hf) + (1-Ome1)*exp(q(+1)-q-r) = 1;
   N*exp(n) = NS*exp(ns) + NB*exp(nb);
   H = HS*exp(hs) + HB*exp(hb) + HF*exp(hf);
@#else
   Y*exp(y-a) = NS*exp(ns) + NB*exp(nb);
   exp(w) = exp(a);
   H = HS*exp(hs) + HB*exp(hb);
@#endif
a = rhoa * a(-1) + etaa;
end;

// ---------------
// 声明初始值
// ---------------
initval;
cs = 0;  
ns = 0;  
hs = 0;  
cb = 0;  
nb = 0;
hb = 0;  
l = 0;     
y = 0;
r = 0;   
q = 0;   
a = 0;
w = 0;  
@#if Factor == 1
   n = 0;   
   hf = 0;
@#endif
end;

steady; 
check;

shocks;
var etaa = siga^2;
end;

stoch_simul(irf = 90, order = 1, noprint, nograph, periods = 0);