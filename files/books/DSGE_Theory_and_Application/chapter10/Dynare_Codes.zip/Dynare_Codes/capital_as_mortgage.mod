%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 该 Mod 文件用于求解资本作为抵押物的模型
% 比较抵押融资约束如何影响经济均衡：
% （1）基准模型：无抵押融资约束
% （2）有融资约束：资本作为抵押物
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 作者: Deng, Guichuan               
% 邮箱: denggch@mail.sysu.edu.cn    
% 最新更新时间: 2026/10/14           
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

// 定义宏变量 Mort: 
// 如果 Mort = 0, 表示基准模型；
// 如果 Mort = 1, 表示有资本作为抵押物，默认值
@#ifndef Mort
    @#define Mort = 1
@#endif

// ------------------
// 声明内生变量
// ------------------
var c n y w k i q r a 
@#if Mort == 1
   l ce
@#endif
;

// -------------
//  声明外生变量
// -------------
varexo etaa;

// ----------
// 声明参数
// ----------
parameters bet vph alp del thi rha siga 
@#if Mort == 1
   bee ome Ome3 
@#endif
R W Y N K I C 
@#if Mort == 1
   L CE
@#endif
;

// --------------
// 校准参数值
// --------------
bet = 0.99;  
vph = 1.99;  
alp = 0.40;  
del = 0.025; 
set_param_value('thi', thi);
rha = 0.88;
siga = 0.01; 
@#if Mort == 1
   bee = 0.98;  
   ome = 0.85;
   Ome3 = 1 - ome*(bet-bee) - bee*(1-del);
   R = 1/bet; 
   W = (1-alp)*(bee*alp/Ome3)^(alp/(1-alp));
   Y = ((1-alp)/(1-alp+alp*ome*(1-bet)*bee/Ome3))^(1/(1+vph))*(bee*alp/Ome3)^(alp/(1-alp));
   N = (1-alp)/W*Y;
   K = bee*alp/Ome3*Y;
   I = del*K;
   C = W/N^vph;
   L = bet*ome*K;
   CE = Y-C-I;
@#else
   R = 1/bet; 
   W = (1-alp)*(bet*alp/(1-bet*(1-del)))^(alp/(1-alp));
   Y = (alp*bet/(1-bet*(1-del)))^(alp/(1-alp))*((1-alp)*(1-bet*(1-del))/(1-bet*(1-del)-alp*bet*del))^(1/(1+vph));
   N = (1-alp)/W*Y;
   K = bet*alp/(1-bet*(1-del))*Y;
   I = del*K;
   C = W/N^vph;
@#endif

// ------------
// 声明模型
// ------------
model;
exp(c) = exp(c(+1) - r);
exp(c + vph*n) = exp(w);
exp(w) = exp(y - n);
exp(k) = (1-del)*exp(k(-1)) + del*exp(i);
exp(y) = exp(a + alp*k(-1) + (1-alp)*n);
exp(q) = 1 + thi*((exp(i - i(-1)) - 1)^2/2 + (exp(i - i(-1)) - 1)*exp(i - i(-1)) - bet*exp(c - c(+1))*(exp(i(+1) - i) - 1)*exp(2*(i(+1) - i)));
@#if Mort == 1
   exp(q) = bee*exp(ce-ce(+1))*((1-del-ome)*exp(q(+1)) + alp*Y/K*exp(y(+1)-k)) + bet*ome*exp(q(+1)-r);
   exp(r + l) = exp(q(+1) + k);
   CE*exp(ce) + I*exp(q+i) + W*N*exp(w+n) + R*L*exp(r(-1)+l(-1)) = Y*exp(y) + L*exp(l);
   exp(y) = C/Y * exp(c) + CE/Y * exp(ce) + I/Y*(1 - thi/2*(exp(i-i(-1)) - 1)^2) * exp(i);
@#else
   R*exp(r) = (1-del)*exp(q(+1)-q) + alp*Y/K*exp(y(+1) - k-q);
   exp(y) = C/Y * exp(c) + I/Y*(1 + thi/2*(exp(i-i(-1)) - 1)^2) * exp(i);
@#endif
a = rha * a(-1) + etaa;
end;

// ---------------
// 声明初始值
// ---------------
initval;
c = 0;  
n = 0;  
y = 0;  
w = 0;
k = 0;  
i = 0;  
q = 0;
r = 0;   
a = 0;
@#if Mort == 1
   l = 0;
   ce= 0;
@#endif
end;

steady;
check;

shocks;
var etaa = siga^2;
end;

stoch_simul(irf = 100, order = 1, noprint, nograph, periods = 0);