%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ��10�£������е�Ѻ����Լ����ģ�ͣ��������Σ�
% (1) ס����Ϊ��Ѻ��
%     ���� 1: ס������Ϊ����Ҫ��
%     ���� 2: ס����Ϊ����Ҫ��
% (2) �ʱ���Ϊ��Ѻ��
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ����: Deng, Guichuan               
% ����: denggch@mail.sysu.edu.cn    
% ���¸���ʱ��: 2026/10/14           
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% �½����ļ���
mkdir('./result');

%% ����һ: ס������Ϊ����Ҫ��
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 4���龰(varphi, omega):
% (1)hh: varphi = 1.99 and omega = 0.85
% (2)hs: varphi = 1.99 and omega = 0.25
% (3)sh: varphi = 0.99 and omega = 0.85
% (4)ss: varphi = 0.99 and omega = 0.25
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% �龰��1������varphi VS ��omega
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all; 
clc;

% �趨����
vph = 1.99; 
ome = 0.85; 

% ����ģ��
dynare house_as_factor.mod -DFactor=0;

% ������
nhho = oo_; 
nm = M_;
save('./result./nhho.mat', 'nhho');
save('./result./nm.mat', 'nm');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% �龰��2������varphi VS ��omega
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all; 
clc;

% �趨����
vph = 1.99; 
ome = 0.25; 

% ����ģ��
dynare house_as_factor.mod -DFactor=0;  

% ������
nhso = oo_; 
save('./result./nhso.mat', 'nhso');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% �龰��3������varphi VS ��omega
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all; 
clc;

% �趨����
vph = 0.99; 
ome = 0.85; 

% ����ģ��
dynare house_as_factor.mod -DFactor=0;   

% ������
nsho = oo_; 
save('./result./nsho.mat', 'nsho');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% �龰��4������varphi VS ��omega
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all; 
clc;

% �趨����
vph = 0.99; 
ome = 0.25; 

% ����ģ��
dynare house_as_factor.mod -DFactor=0;  

% ������
nsso = oo_; 
save('./result./nsso.mat', 'nsso');

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ס������Ϊ����Ҫ��ʱ
% ��Ѻ����Լ���Ժ�۾��õ�Ӱ��
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all; 
clc;

% ��������
load('./result./nhho.mat');
load('./result./nhso.mat');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ͼ10.1����ͼ���е�Ѻ vx �޵�Ѻ��
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% varphi=1.99 and omega=0.85;
T = 20; t = 1:T;
h0 = figure
set(h0,'Units','centimeters','Position',[2 2 14 12]);
subplot(3, 3, 1);
plot(t, nhho.irfs.y_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, nhho.irfs.a_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$y_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 2);
plot(t, nhho.irfs.cs_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, nhho.irfs.a_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$c_t^S$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 3)
plot(t, nhho.irfs.cb_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, nhho.irfs.a_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$c_t^B$', 'interpreter', 'latex', 'fontsize', 14);

subplot(3, 3, 4)
plot(t, nhho.irfs.q_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, nhho.irfs.a_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$q_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 5)
plot(t, nhho.irfs.hs_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, nhho.irfs.a_etaa(t)*0, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$h_t^S$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 6)
plot(t, nhho.irfs.hb_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, nhho.irfs.a_etaa(t)*0, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$h_t^B$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 7)
plot(t, nhho.irfs.r_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, (0.88-1)*nhho.irfs.a_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$\hat{r}_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 8)
plot(t, nhho.irfs.ns_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, nhho.irfs.a_etaa(t)*0, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$n_t^S$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 9)
plot(t, nhho.irfs.nb_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, nhho.irfs.a_etaa(t)*0, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$n_t^B$', 'interpreter', 'latex', 'fontsize', 12);

legend({'����Լ��', '��׼ģ��'}, 'Orientation', 'horizontal', ...
    'position', [0.35 0.01 0.20 0.05], ...
    'fontname', 'kaiti', 'fontsize', 10.5);
legend('boxoff');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ͼ10.2����ͼ����ͬ����Լ���̶ȣ�
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% omega=0.85 vs omega=0.25;
h1 = figure
set(h1,'Units','centimeters','Position',[2 2 14 12]);
subplot(3, 3, 1);
plot(t, nhho.irfs.y_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, nhso.irfs.y_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$y_t$', 'interpreter', 'latex', 'fontsize', 12)

subplot(3, 3, 2);
plot(t, nhho.irfs.cs_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, nhso.irfs.cs_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$c_t^S$', 'interpreter', 'latex', 'fontsize', 12)

subplot(3, 3, 3)
plot(t, nhho.irfs.cb_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, nhso.irfs.cb_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$c_t^B$', 'interpreter', 'latex', 'fontsize', 14)

subplot(3, 3, 4)
plot(t, nhho.irfs.q_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, nhso.irfs.q_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$q_t$', 'interpreter', 'latex', 'fontsize', 12)

subplot(3, 3, 5)
plot(t, nhho.irfs.hs_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, nhso.irfs.hs_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$h_t^S$', 'interpreter', 'latex', 'fontsize', 12)

subplot(3, 3, 6)
plot(t, nhho.irfs.hb_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, nhso.irfs.hb_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$h_t^B$', 'interpreter', 'latex', 'fontsize', 12)

subplot(3, 3, 7)
plot(t, nhho.irfs.r_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, nhso.irfs.r_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$\hat{r}_t$', 'interpreter', 'latex', 'fontsize', 12)

subplot(3, 3, 8)
plot(t, nhho.irfs.ns_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, nhso.irfs.ns_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$n_t^S$', 'interpreter', 'latex', 'fontsize', 12)

subplot(3, 3, 9)
plot(t, nhho.irfs.nb_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, nhso.irfs.nb_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$n_t^B$', 'interpreter', 'latex', 'fontsize', 12)

legend({'$\omega=0.85$', '$\omega=0.25$'}, 'Orientation', 'horizontal', ...
    'Interpreter', 'latex', 'position', [0.35 0.01 0.20 0.05], ...
    'fontname', 'kaiti', 'fontsize', 10.5);
legend('boxoff');


%% ���ζ�: ס����Ϊ����Ҫ��
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 4���龰(varphi, omega):
% (1)hh: varphi = 1.99 and omega = 0.85
% (2)hs: varphi = 1.99 and omega = 0.25
% (3)sh: varphi = 0.99 and omega = 0.85
% (4)ss: varphi = 0.99 and omega = 0.25
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% �龰��1������varphi VS ��omega
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all; 
clc;

% �趨����ֵ
vph = 1.99; 
ome = 0.85; 

% ����ģ��
dynare house_as_factor.mod;

% ������
yhho = oo_; ym = M_;
save('./result./yhho.mat', 'yhho');
save('./result./ym.mat', 'ym');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% �龰��2������varphi VS ��omega
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all; 
clc;

% �趨����ֵ
vph = 1.99; ome = 0.25; 

% ����ģ��
dynare house_as_factor.mod; 

% ������
yhso = oo_; 
save('./result./yhso.mat', 'yhso');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% �龰��3������varphi VS ��omega
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all; 
clc;

% �趨����ֵ
vph = 0.99; 
ome = 0.85; 

% ����ģ��
dynare house_as_factor.mod; 

% ������
ysho = oo_; 
save('./result./ysho.mat', 'ysho');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% �龰��4������varphi VS ��omega
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all; 
clc;

% �趨����ֵ
vph = 0.99; 
ome = 0.25; 

% ����ģ��
dynare house_as_factor.mod; 

% ������
ysso = oo_; 
save('./result./ysso.mat', 'ysso');

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ס����Ϊ����Ҫ��ʱ
% ��Ѻ����Լ���Ժ�۾��õ�Ӱ��
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all; 
clc;

% ��������
load('./result./yhho.mat');
load('./result./yhso.mat');
load('./result./nhho.mat');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ͼ10.3����ͼ����Ϊ����Ҫ�� vs ����Ϊ����Ҫ�أ�
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
h2 = figure
set(h2,'Units','centimeters','Position',[2 2 14 12]);
subplot(3, 3, 1);
plot(t, yhho.irfs.y_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, nhho.irfs.y_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$y_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 2);
plot(t, yhho.irfs.cs_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, nhho.irfs.cs_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$c_t^S$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 3);
plot(t, yhho.irfs.cb_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, nhho.irfs.cb_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$c_t^B$', 'interpreter', 'latex', 'fontsize', 14);

subplot(3, 3, 4);
plot(t, yhho.irfs.q_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, nhho.irfs.q_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$q_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 5);
plot(t, yhho.irfs.hs_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, nhho.irfs.hs_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$h_t^S$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 6);
plot(t, yhho.irfs.hb_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, nhho.irfs.hb_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$h_t^B$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 7);
plot(t, yhho.irfs.hf_etaa(t)*100, 'k-', 'LineWidth', 1);
xlim([0 T]); title('$h_t^F$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 8);
plot(t, yhho.irfs.ns_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, nhho.irfs.ns_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$n_t^S$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 9);
plot(t, yhho.irfs.nb_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, nhho.irfs.nb_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$n_t^B$', 'interpreter', 'latex', 'fontsize', 12)

legend({'������Ҫ��', '������Ҫ��'}, 'Orientation', 'horizontal', ...
    'position', [0.35 0.01 0.25 0.05], 'fontname', 'kaiti', 'fontsize', 10.5);
legend('boxoff');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ͼ10.4����ͼ��ס����Ϊ����Ҫ��ʱ������Լ��vs������Լ��
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
T = 20; t = 1:T;
h0 = figure
set(h0,'Units','centimeters','Position',[2 2 14 12]);
subplot(3, 3, 1);
plot(t, yhho.irfs.y_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, yhho.irfs.a_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$y_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 2);
plot(t, yhho.irfs.cs_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, yhho.irfs.a_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$c_t^S$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 3)
plot(t, yhho.irfs.cb_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, yhho.irfs.a_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$c_t^B$', 'interpreter', 'latex', 'fontsize', 14);

subplot(3, 3, 4)
plot(t, yhho.irfs.q_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, yhho.irfs.a_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$q_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 5)
plot(t, yhho.irfs.hs_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, yhho.irfs.a_etaa(t)*0, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$h_t^S$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 6)
plot(t, yhho.irfs.hb_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, yhho.irfs.a_etaa(t)*0, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$h_t^B$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 7)
plot(t, yhho.irfs.hf_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, yhho.irfs.a_etaa(t)*0, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$h_t^F$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 8)
plot(t, yhho.irfs.ns_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, yhho.irfs.a_etaa(t)*0, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$n_t^S$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 9)
plot(t, yhho.irfs.nb_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, yhho.irfs.a_etaa(t)*0, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$n_t^B$', 'interpreter', 'latex', 'fontsize', 12);

legend({'����Լ��', '��׼ģ��'}, 'Orientation', 'horizontal', ...
    'position', [0.35 0.01 0.20 0.05], ...
    'fontname', 'kaiti', 'fontsize', 10.5);
legend('boxoff');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ͼ10.5����ͼ��ס����Ϊ����Ҫ��ʱ������Լ��vs������Լ��
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
h1 = figure
set(h1,'Units','centimeters','Position',[2 2 14 12]);
subplot(3, 3, 1);
plot(t, yhho.irfs.y_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, yhso.irfs.y_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$y_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 2);
plot(t, yhho.irfs.cs_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, yhso.irfs.cs_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$c_t^S$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 3)
plot(t, yhho.irfs.cb_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, yhso.irfs.cb_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$c_t^B$', 'interpreter', 'latex', 'fontsize', 14);

subplot(3, 3, 4)
plot(t, yhho.irfs.q_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, yhso.irfs.q_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$q_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 5)
plot(t, yhho.irfs.hs_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, yhso.irfs.hs_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$h_t^S$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 6)
plot(t, yhho.irfs.hb_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, yhso.irfs.hb_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$h_t^B$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 7)
plot(t, yhho.irfs.hf_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, yhso.irfs.hf_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$h_t^F$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 8)
plot(t, yhho.irfs.ns_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, yhso.irfs.ns_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$n_t^S$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 9)
plot(t, yhho.irfs.nb_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, yhso.irfs.nb_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$n_t^B$', 'interpreter', 'latex', 'fontsize', 12);

legend({'$\omega=0.85$', '$\omega=0.25$'}, 'Orientation', 'horizontal', ...
    'interpreter', 'latex', 'position', [0.35 0.01 0.20 0.05], ...
    'fontname', 'kaiti', 'fontsize', 10.5);
legend('boxoff');



%% �������ʱ���Ϊ��Ѻ��
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ����������ʱ���Ϊ��Ѻ��ʱ��DSGEģ�ͣ�
% �����������ʱ���Ϊ��Ѻ�ʲ��Ժ�۾��õ�Ӱ��
% �������Σ�
% (1) ��Ͷ�ʵ����ɱ���thetai = 0;  
% (2) ��Ͷ�ʵ����ɱ���thetai = 10; 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (1) ���ʱ������ɱ���thetai = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ��1.1���ʱ���Ϊ��Ѻ��
clear; 
close all; 
clc;

% �趨�ʱ������ɱ�����
thi = 0; 

% ����ģ��:�ʱ���Ϊ��Ѻ��
dynare capital_as_mortgage.mod; 

% ���������
co0 = oo_; cm = M_;
save('./result./co0.mat', 'co0');
save('./result./cm.mat', 'cm');

%��1.2����׼ģ��
clear; 
close all; 
clc;

% �趨�ʱ������ɱ�����
thi = 0; 

% ����ģ��
dynare capital_as_mortgage.mod -DMort=0; 

% ������
cbo0 = oo_; cbm = M_;
save('./result./cbo0.mat', 'cbo0');
save('./result./cbm.mat', 'cbm');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (2) ���ʱ������ɱ���thetai = 10;  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ��2.1���ʱ���Ϊ��Ѻ��
clear; 
close all; 
clc;

% �趨�ʱ������ɱ�����
thi=10; 

% ����ģ��
dynare capital_as_mortgage.mod; 

% ������
co = oo_;
save('./result./co.mat', 'co');

% ��2.2����׼ģ��
clear; 
close all; 
clc;

% �趨�ʱ������ɱ�����
thi=10; 

% ����ģ��
dynare capital_as_mortgage.mod -DMort=0; 

% ������
cbo = oo_;
save('./result./cbo.mat', 'cbo');

%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% �Ƚ����޵�Ѻ����Լ��ʱ��۾��ò���
% ���������Σ�
%��1����Ͷ�ʵ����ɱ���
%��2����Ͷ�ʵ����ɱ���
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (1) ��Ͷ�ʵ����ɱ�ʱ��thetai = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all; 
clc;

% ��������
load('./result./co0.mat');
load('./result./cbo0.mat');

%%%%%%%%%%%%%%%%%%%%%%%%
% ͼ10.6����ͼ
%%%%%%%%%%%%%%%%%%%%%%%%
T = 40; t = 1:T;
h0 = figure
set(h0,'Units','centimeters','Position', [2 2 14 12]);
subplot(3, 3, 1);
plot(t, co0.irfs.y_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, cbo0.irfs.y_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$y_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 2);
plot(t, co0.irfs.c_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, cbo0.irfs.c_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$c_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 3)
plot(t, co0.irfs.ce_etaa(t)*100, 'k-', 'LineWidth', 1);
xlim([0 T]); title('$c_t^e$', 'interpreter', 'latex', 'fontsize', 14);

subplot(3, 3, 4)
plot(t, co0.irfs.w_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, cbo0.irfs.w_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$\hat{w}_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 5)
plot(t, co0.irfs.k_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, cbo0.irfs.k_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$k_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 6)
plot(t, co0.irfs.i_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, cbo0.irfs.i_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$i_t$', 'interpreter', 'latex', 'fontsize', 12)

subplot(3, 3, 7)
plot(t, co0.irfs.r_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, cbo0.irfs.r_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$\hat{r}_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 8)
plot(t, co0.irfs.n_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, cbo0.irfs.n_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$n_t$', 'interpreter', 'latex', 'fontsize', 12);

legend({'����Լ��', '��׼ģ��'}, 'Orientation', 'horizontal', ...
    'position', [0.35 0.01 0.25 0.05], ...
    'fontname', 'kaiti', 'fontsize', 10.5);
legend('boxoff');

subplot(3, 3, 9)
plot(t, co0.irfs.l_etaa(t)*100, 'k-', 'LineWidth', 1);
xlim([0 T]); title('$l_t$', 'interpreter', 'latex', 'fontsize', 12);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% (2) ��Ͷ�ʵ����ɱ�ʱ��thetai = 10;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear; 
close all; 
clc;

% ��������
load('./result./co.mat');
load('./result./cbo.mat');

%%%%%%%%%%%%%%%%%
% ͼ10.7����ͼ
%%%%%%%%%%%%%%%%%
T = 40; t = 1:T;
h0 = figure
set(h0,'Units','centimeters','Position',[2 2 14 12]);
subplot(3, 3, 1);
plot(t, co.irfs.y_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, cbo.irfs.y_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$y_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 2);
plot(t, co.irfs.c_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, cbo.irfs.c_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$c_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 3)
plot(t, co.irfs.ce_etaa(t)*100, 'k-', 'LineWidth', 1);
xlim([0 T]); title('$c_t^e$', 'interpreter', 'latex', 'fontsize', 14);

subplot(3, 3, 4)
plot(t, co.irfs.q_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, cbo.irfs.q_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$q_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 5)
plot(t, co.irfs.k_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, cbo.irfs.k_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); ylabel('%'); title('$k_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 6)
plot(t, co.irfs.i_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, cbo.irfs.i_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$i_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 7)
plot(t, co.irfs.r_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, cbo.irfs.r_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$\hat{r}_t$', 'interpreter', 'latex', 'fontsize', 12);

subplot(3, 3, 8)
plot(t, co.irfs.n_etaa(t)*100, 'k-', 'LineWidth', 1);
hold on;
plot(t, cbo.irfs.n_etaa(t)*100, 'Color', [0.3,0.3,0.3], 'Linestyle', '--', 'LineWidth', 1);
hold off;
xlim([0 T]); title('$n_t$', 'interpreter', 'latex', 'fontsize', 12);

legend({'����Լ��', '��׼ģ��'}, 'Orientation', 'horizontal', ...
    'position', [0.35 0.01 0.25 0.05], ...
    'fontname', 'kaiti', 'fontsize', 10.5);
legend('boxoff');

subplot(3, 3, 9)
plot(t, co.irfs.l_etaa(t)*100, 'k-', 'LineWidth', 1);
xlim([0 T]); title('$l_t$', 'interpreter', 'latex', 'fontsize', 12);