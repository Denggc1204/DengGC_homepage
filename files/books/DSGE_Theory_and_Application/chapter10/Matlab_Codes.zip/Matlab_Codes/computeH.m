%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 该 M 文件用于求解 H 稳态值
% 输入值：x, H 取值
%        s, 1 表示住房不作为生产要素（情形一）
%           2 表示住房作为生产要素（情形二）
%        para, 参数值，包括(betas betab varphi
%              omega epsilon delta alpha)       
% 输出值：err
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 作者: Deng, Guichuan               
% 邮箱: denggch@mail.sysu.edu.cn    
% 最新更新时间: 2026/10/14           
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function err = computeH(x, s, para)
bts = para(1);
btb = para(2);
vph = para(3);
ome = para(4);
alp = para(5);
eps = para(6);
del = para(7);
mu = (eps - 1)/eps;
Ome1 = 1 - bts*(1-del);
Ome2 = 1 - btb*(1-del) - ome*(bts - btb);
Omes = 1 + (del + ome*(1-bts))/Ome2;
H = x;
if s == 1
   W = mu;
   err = (Ome1*H - Omes^(1/(1+vph)) - (Ome1/Ome2 - 1)*W*Omes^(-vph/(1+vph))).^vph - (W/Ome1)./(H - W*Omes^(-vph/(1+vph))/Ome2);
else
   W = (1-alp)*mu^(1/(1-alp))*(alp/Ome1)^(alp/(1-alp));
   HB = W*Omes^(-vph/(1+vph))/Ome2;
   CB = W*Omes^(-vph/(1+vph));
   NB = Omes^(1/(1+vph));
   HF = alp*mu/(1+alp*mu)*(H - HB + CB/Ome1);
   HS = H - HB - HF;
   CS = Ome1*HS;
   err = CS.*((1-alp)*mu/W*(CS+CB) - NB).^vph - W;
end
