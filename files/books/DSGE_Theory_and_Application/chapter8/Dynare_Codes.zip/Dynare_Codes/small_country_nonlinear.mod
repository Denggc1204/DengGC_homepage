%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 第8章：小国模型（非线性形式）
% 两种情形：                       
% （1）金融市场是否完备
% （2）LCP；             
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 作者: Deng, Guichuan             
% 邮箱: denggch@mail.sysu.edu.cn   
% 最新更新时间: 2026/10/15         
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

// -------------
// 声明内生变量
// -------------
var 
// 弹性价格变量
ybarst ybar qbar pHbar
// 黏性价格变量
cst yst nst pist rst wst pFstdot s1st s2st vFst ygapst ast
c y n piH pi r w pHdot pH s1 s2 vH ygap q cH cHst cF a;

// --------------
//  声明外生变量
// --------------
varexo etaa etaast;

// ---------
// 声明参数
// ---------
parameters bet sig vphi eta o tht eps ome rhor phipi phiy phiq
rhoa rhoast siga sigast; 

bet     =   0.99; 
sig     =   2.11; 
vphi    =   1.00;
eta     =   2.50; 
o       =   0.37; 
tht     =   0.75;
eps     =   10.0; 
set_param_value('ome', ome);
rhor    =   0.75; 
phipi   =   1.50;
phiy    =   0.125;
set_param_value('phiq', phiq);
rhoa    =   0.50; 
siga    =   0.01;
rhoast  =   0.50; 
sigast  =   0.01; 

// --------
// 声明模型
// --------
model;
// ---------------
// 弹性价格系统
// ---------------
exp(ybarst) = exp((1+vphi)/(sig+vphi)*ast);
exp(sig*ybarst + qbar + vphi*ybar) = exp((1+vphi)*a + pHbar);
exp(ybar) = ((1-o)*exp(1/sig*qbar) + o*exp(eta*qbar))*exp(-eta*pHbar + ybarst);
(1-o)*exp((1-eta)*pHbar) + o*exp((1-eta)*qbar) = 1;

// ----------------------------
// 黏性价格系统（大国行为方程）
// ----------------------------
// Equ(1): 消费-储蓄决策
exp(-sig * (cst(+1) - cst) + rst - pist(+1)) = 1;

// Equ(2): 劳动供给方程
exp(wst) = exp(sig * cst + vphi * nst);

// Equ(3)-(6): 生产价格指数
exp(pFstdot) = exp(s1st - s2st);
exp(s1st) = (1 - bet*tht) * exp((1-sig)*cst + wst - ast) + bet*tht*exp(eps * pist(+1) + s1st(+1));
exp(s2st) = (1 - bet*tht) * exp((1-sig)*cst) + bet*tht*exp((eps-1)*pist(+1) + s2st(+1));
tht * exp((eps - 1) * pist) + (1-tht) * exp((1-eps) * pFstdot) = 1;

// Equ(7): 产品市场出清条件
exp(yst) = exp(cst + vFst);

// Equ(8) : 生产价格分散度
exp(vFst) = tht * exp(eps*pist + vFst(-1)) + (1 - tht) * exp(-eps*pFstdot);

// Equ(9): 生产函数
exp(yst) = exp(ast + nst);

// Equ(10): 货币政策方程
rst = rhor * rst(-1) + (1-rhor) * (phiy * ygapst + phipi * pist);

// Equ(11): 产出缺口
exp(ygapst) = exp(yst - ybarst);

// Equ(12): 生产率冲击
ast = rhoast * ast(-1) + etaast;

// ----------------------------
// 黏性价格系统（小国行为方程）
// ----------------------------
// Equ(1): 消费-储蓄决策
exp(-sig * (c(+1) - c) + r - pi(+1)) = 1;

// Equ(2): 劳动供给方程
exp(w) = exp(sig * c + vphi * n);

// Equ(3-6): 生产价格指数
exp(pHdot - pH) = exp(s1 - s2);
exp(s1) = (1 - bet*tht) * exp(- eta*pH + (1-sig)*c + w - a) + bet*tht * exp(eps * piH(+1) + s1(+1));
exp(s2) = (1 - bet*tht) * exp((1 - eta)*pH + (1-sig)*c) + bet*tht * exp((eps-1) * piH(+1) + s2(+1));
tht * exp((eps - 1) * piH) + (1 - tht) * exp((1 - eps) * (pHdot - pH)) = 1;

// Equ(7): 产品市场出清条件
exp(y) = ((1 - o)*exp(c) + o*exp(eta*q + cst))*exp(-eta*pH + vH);

// Equ(8) : 生产价格分散度
exp(vH) = tht * exp(eps*piH + vH(-1)) + (1 - tht) * exp(-eps*(pHdot - pH));

// Equ(9): 生产函数
exp(y) = exp(n + a);

// Equ(10): 消费价格指数
(1-o)*exp((1 - eta) * pH) + o*exp((1 - eta) * q) = 1;

// Equ(11): 定义实际价格
exp(piH) = exp(pi + pH - pH(-1));

// Equ(12): 国际风险分担条件
exp(-sig*ome*(c-cst)+ome*q) * ((1-o+o*exp((1-eta)*(q-pH)))/(1-o+o*exp(eta*q+cst-c)))^(1-ome) = 1;

// Equ(13): 货币政策
r = rhor * r(-1) + (1-rhor) * (phiy * ygap + phipi * piH + phiq * q);

// Equ(14): 产出缺口
exp(ygap) = exp(y - ybar);

// Equ(16): 小国对小国产品的消费
exp(cH) = exp(-eta*pH + c);

// Equ(17): 小国对大国产品的消费（进口）
exp(cF) = exp(-eta*q + c);

// Equ(18): 大国对小国的消费（出口）
exp(cHst) = exp(-eta*(pH - q) + cst);

// Equ(15): 生产率冲击
a = rhoa * a(-1) + etaa;
end;

// ----------
// 声明初始值
// ----------
initval;
ybarst   =  0; 
ybar     =  0; 
qbar     =  0; 
pHbar    =  0; 
cst      =  0; 
yst      =  0; 
nst      =  0; 
pist     =  0; 
rst      =  0; 
wst      =  0; 
pFstdot  =  0; 
s1st     =  0; 
s2st     =  0; 
vFst     =  0; 
ygapst   =  0; 
ast      =  0; 
c        =  0; 
y        =  0; 
n        =  0; 
piH      =  0; 
pi       =  0; 
r        =  0; 
w        =  0; 
pHdot    =  0; 
pH       =  0; 
s1       =  0; 
s2       =  0; 
vH       =  0; 
ygap     =  0; 
q        =  0; 
cH       =  0; 
cHst     =  0; 
cF       =  0;
a        =  0; 
end;

steady;
check;

shocks;
var etaa = siga^2;
var etaast = sigast^2;
end;

stoch_simul(irf = 100, order = 1, nograph, noprint, periods = 0);