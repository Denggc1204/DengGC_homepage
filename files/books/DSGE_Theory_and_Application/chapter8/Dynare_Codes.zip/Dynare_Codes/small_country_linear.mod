%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 第8章：小国模型（对数线性化形式）
% 金融市场不完备           
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 作者: Deng, Guichuan             
% 邮箱: denggch@mail.sysu.edu.cn   
% 最新更新时间: 2026/10/15         
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

// -------------
// 声明内生变量
// -------------
var 
ygapst pist rst rbarst ybarst cst ast
ygap piH r ybar q a;

// --------------
//  声明外生变量
// --------------
varexo etaa etaast;

// ---------
// 声明参数
// ---------
parameters bet sig vphi eta o tht ome rhor phiy phipi phiq rhoa siga rhoast sigast kap D Psi Phi;

// -------------------
//  校准参数值
// -------------------
bet     =      0.99;
sig     =      2.11;
vphi    =      1.00;
eta     =      2.50;
o       =      0.37;
tht     =      0.75;
set_param_value('ome', ome);
rhor    =      0.75;
phiy    =      0.125;
phipi   =      1.50;
set_param_value('phiq', phiq);
rhoa    =      0.50;
siga    =      0.01;
rhoast  =      0.50;
sigast  =      0.01;
kap     =      (1-tht)*(1-bet*tht)/tht;
D       =      sig*eta*o*(2-o) + (1-o)^2;
Psi     =      eta*o*(2-o)*((sig+o)*ome - o)/((1-2*eta+eta*o)*o+(1-2*o+2*eta*o-eta*o^2)*ome);
Phi     =      eta*(2-o)*(1-o+Psi)/(sig*eta*(2-o)+Psi);

// --------
// 声明模型
// --------
model(linear);
// ----------------
// 大国经济主体行为
// ----------------
ygapst = ygapst(+1) - 1/sig*(rst - pist(+1) - rbarst);
pist = bet*pist(+1) + kap*(sig+vphi)*ygapst;
rst = rhor*rst(-1) + (1-rhor)*(phiy*ygapst + phipi*pist);
rbarst = sig*(1+vphi)/(sig+vphi)*(ast(+1) - ast);
ybarst = (1+vphi)/(sig+vphi)*ast;
cst = ygapst + ybarst;
ast = rhoast * ast(-1) + etaast;

// ---------------
// 小国经济主体行为
// ---------------
ygap = ygap(+1) - eta*(2-o)*(1-o+Psi)/(sig*eta*(2-o)+Psi)*(r - piH(+1)) + ybar(+1) - ybar + (sig*eta*(2-o)*(Psi-o)-Psi)/(sig*eta*(2-o)+Psi) * (cst(+1) - cst);
piH = kap*(((sig*eta*(2-o)+Psi)/(eta*(2-o)*(1-o+Psi)) + vphi)*(ygap+ybar) - (1+vphi)*a + (sig*eta*(2-o)*(Psi-o)-Psi)/(eta*(2-o)*(1-o+Psi)) * cst) + bet*piH(+1);
r = rhor*r(-1) + (1-rhor)*(phiy*ygap + phipi*piH + phiq*q);
ybar = D*(1+vphi)/(sig+D*vphi)*a + (1-D)*sig/(sig+D*vphi)*ybarst;
q = (1-o)/(eta*o*(2-o))*Psi/(1-o+Psi)*(ygap + ybar) - (1-o)/(eta*o*(2-o))*Psi/(1-o+Psi)*(ybarst+ygapst);
a = rhoa * a(-1) + etaa;
end;

// ----------
// 声明初始值
// ----------
initval;
ygapst=   0;
pist  =   0; 
rst   =   0;
rbarst=   0;
ybarst=   0;
cst   =   0;
ast   =   0;
ygap  =   0;
piH   =   0;
r     =   0;
ybar  =   0;
q     =   0;
a     =   0;
end;

steady;
check;

shocks;
var etaa = siga^2;
var etaast = sigast^2;
end;

stoch_simul(irf = 50, order = 1, nograph, noprint, periods = 0);