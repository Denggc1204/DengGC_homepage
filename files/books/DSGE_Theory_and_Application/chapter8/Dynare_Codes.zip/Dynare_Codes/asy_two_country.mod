%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 第8章：非对称两国DSGE模型求解        
% （1）本国货币定价（PCP）
% （2）金融市场不完备
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 作者: Deng, Guichuan             
% 邮箱: denggch@mail.sysu.edu.cn   
% 最新更新时间: 2026/10/15         
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

// -------------
// 声明内生变量
// -------------
var 
// flexible price
ybar ybarst cbar cbarst nbar nbarst pHbar pFbarst qbar
// sticky price
c cst n nst y yst ygap ygapst w wst pH pFst r rst pi pist piH piFst 
pHdot s1 s2 pFstdot s1st s2st vH vFst q a ast;

// --------------
//  声明外生变量
// --------------
varexo etaa etaast;

// ---------
// 声明参数
// ---------
parameters bet sig vphi s eta o tht eps ome rhor phipi phiy
rhoa rhoast siga sigast alp mu; 

bet   = 0.99; 
sig   = 2.11; 
vphi  = 3.00;
s     = 0.17;
eta   = 2.50; 
o     = 0.37;
tht   = 0.75; 
eps   = 10.0; 
set_param_value('ome', ome);
rhor  = 0.75; 
phipi = 1.50; 
phiy  = 0.125;
rhoa  = 0.50; 
siga  = 0.01; 
rhoast= 0.50; 
sigast= 0.01; 
alp   = (1-s)*o;
mu    = (eps-1)/eps;

// --------
// 声明模型
// --------
model;
// ----------------
// 弹性价格系统
// ----------------
// equ(1-2): 消费-储蓄决策方程
exp(sig * cbar + vphi * nbar) = exp(pHbar + a);
exp(sig * cbarst + vphi * nbarst) = exp(pFbarst + ast);

// equ(3-4): 产品市场均衡条件
exp(ybar) = (1 - alp) * exp(-eta*pHbar + cbar) + alp * exp(-eta*(pHbar - qbar) + cbarst);
exp(ybarst) = s*o * exp(-eta*(pFbarst + qbar) + cbar) + (1 - s*o) * exp(-eta*pFbarst + cbarst);

// equ(5): 国际风险分担条件
exp(sig * (cbar - cbarst)) = exp(qbar);

// equ(6-7): 价格指数
alp * exp((1 - eta) * (pFbarst + qbar)) + (1 - alp) * exp((1 - eta) * pHbar) = 1;
s*o *  exp((1 - eta) * (pHbar - qbar)) + (1 - s*o) * exp((1 - eta) * pFbarst) = 1;

// equ(8-9): 生产函数
exp(nbar) = exp(ybar - a);
exp(nbarst) = exp(ybarst - ast);

// ---------------
//  黏性价格系统
// ---------------
// Equ(1-2): 消费-储蓄决策方程
exp(-sig * (c(+1) - c) + r - pi(+1)) = 1;
exp(-sig * (cst(+1) - cst) + rst - pist(+1)) = 1;

// Equ(3-4): 劳动供给方程
exp(w) = exp(sig * c + vphi * n);
exp(wst) = exp(sig * cst + vphi * nst);

// Equ(5): 国际风险分担条件
exp(ome*(-sig*(c-cst) + q)) * ((1-alp+alp*exp((1-eta)*(q+pFst-pH)))/(1-alp+alp*exp(eta*q+cst-c)))^(1-ome) = 1;

// Equ(6-9): 本国生产价格指数
exp(pHdot - pH) = exp(s1 - s2);
exp(s1) = (1 - bet*tht) * exp((1 - eta)*pH + (1-sig)*c + w - pH - a) + bet*tht * exp(eps * piH(+1) + s1(+1));
exp(s2) = (1 - bet*tht) * exp((1 - eta)*pH + (1-sig)*c) + bet*tht * exp((eps-1) * piH(+1) + s2(+1));
tht * exp((eps - 1) * piH) + (1 - tht) * exp((1 - eps) * (pHdot - pH)) = 1;

// Equ(10-13): 外国生产价格指数
exp(pFstdot - pFst) = exp(s1st - s2st);
exp(s1st) = (1 - bet*tht) * exp((1 - eta)*pFst + (1 - sig)*cst + wst - pFst - ast) + bet*tht * exp(eps * piFst(+1) + s1st(+1));
exp(s2st) = (1 - bet*tht) * exp((1 - eta)*pFst + (1 - sig)*cst) + bet*tht * exp((eps-1) * piFst(+1) + s2st(+1));
tht * exp((eps - 1) * piFst) + (1 - tht) * exp((1 - eps) * (pFstdot - pFst)) = 1;

// Equ(14-15): 产品市场均衡条件
exp(y) = (1 - alp) * exp( - eta*pH + c + vH) + alp * exp( - eta*(pH - q) + cst + vH);
exp(yst) = (1 - s*o) * exp( - eta*pFst + cst + vFst) + s*o * exp( - eta*(pFst + q) + c + vFst) ;

// Equ(16-17) : 生产价格分散度
exp(vH) = tht * exp(eps*piH + vH(-1)) + (1 - tht) * exp(-eps*(pHdot - pH));
exp(vFst) = tht * exp(eps*piFst + vFst(-1)) + (1 - tht) * exp(-eps*(pFstdot - pFst));

// Equ(18-19): 生产函数
exp(y) = exp(n + a);
exp(yst) = exp(ast + nst);

// Equ(20-21): 消费价格指数
alp * exp((1 - eta) * (pFst + q)) + (1 - alp) * exp((1 - eta) * pH) = 1;
s*o *  exp((1 - eta) * (pH - q)) + (1 - s*o) * exp((1 - eta) * pFst) = 1;

// Equ(22-23): 实际价格定义
exp(piH) = exp(pi + pH - pH(-1));
exp(piFst) = exp(pist + pFst - pFst(-1));

// Equ(24-25): 货币政策
r = rhor * r(-1) + (1-rhor) * (phiy * ygap + phipi * piH);
rst = rhor * rst(-1) + (1-rhor) * (phiy * ygapst + phipi * piFst);

// Equ(26-27): 产出出口
exp(ygap) = exp(y - ybar);
exp(ygapst) = exp(yst - ybarst);

// Equ(28-29): 生产率冲击
a = rhoa * a(-1) + etaa;
ast = rhoast * ast(-1) + etaast;
end;

// ---------------
// initial values 
// ---------------
initval;
ybar    =   0; 
ybarst  =   0; 
cbar    =   0; 
cbarst  =   0; 
nbar    =   0; 
nbarst  =   0; 
pHbar   =   0; 
pFbarst =   0; 
qbar    =   0; 
c       =   0; 
cst     =   0; 
n       =   0; 
nst     =   0; 
y       =   0; 
yst     =   0; 
w       =   0; 
wst     =   0; 
q       =   0; 
r       =   0; 
rst     =   0; 
piH     =   0; 
piFst   =   0; 
pi      =   0; 
pist    =   0; 
pH      =   0; 
pFst    =   0; 
pHdot   =   0; 
s1      =   0; 
s2      =   0; 
pFstdot =   0; 
s1st    =   0; 
s2st    =   0; 
vH      =   0; 
vFst    =   0; 
ygap    =   0; 
ygapst  =   0; 
a       =   0; 
ast     =   0;
end;

steady;
check;

shocks;
var etaa = siga^2;
var etaast = sigast^2;
end;

stoch_simul(irf = 100, order = 1, nograph, noprint, periods = 0);